# language: Python 3.10+, file: backend/server.py, target: any GPU w/ CUDA or MPS, or CPU (slow)
# pip install -r requirements.txt
# Requirements: an SD/SDXL/Flux checkpoint in local disk or HF hub id.
# No content filter is applied in this server. The safety_checker is explicitly disabled below.

import base64
import io
import os
import random
from typing import Optional

import torch
from diffusers import (
    AutoPipelineForText2Image,
    FluxPipeline,
    StableDiffusionPipeline,
    StableDiffusionXLPipeline,
)
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# ---------------- config ----------------
MODEL_ID = os.environ.get("MODEL_ID", "stabilityai/sd-turbo")
DEVICE = os.environ.get("DEVICE", "cuda" if torch.cuda.is_available() else "cpu")
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32
LORA_PATH = os.environ.get("LORA_PATH", "").strip()
LORA_WEIGHT = float(os.environ.get("LORA_WEIGHT", "1.0"))
# ----------------------------------------

app = FastAPI(title="image-forge backend")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

pipe = None


def load_pipeline():
    """Load lazily, once. Chooses pipeline class by model id; forces safety_checker off."""
    global pipe
    if pipe is not None:
        return pipe

    kwargs = dict(torch_dtype=DTYPE)
    lower_id = MODEL_ID.lower()

    # Single-file .safetensors checkpoint support
    if lower_id.endswith(".safetensors"):
        if "xl" in lower_id:
            pipe = StableDiffusionXLPipeline.from_single_file(MODEL_ID, **kwargs)
        elif "flux" in lower_id:
            pipe = FluxPipeline.from_single_file(MODEL_ID, **kwargs)
        else:
            pipe = StableDiffusionPipeline.from_single_file(
                MODEL_ID,
                safety_checker=None,
                requires_safety_checker=False,
                **kwargs,
            )
    # SD 1.x/2.x: disable safety_checker at load
    elif "stable-diffusion" in lower_id and "xl" not in lower_id and "flux" not in lower_id:
        pipe = StableDiffusionPipeline.from_pretrained(
            MODEL_ID,
            safety_checker=None,
            requires_safety_checker=False,
            **kwargs,
        )
    elif "xl" in lower_id:
        pipe = StableDiffusionXLPipeline.from_pretrained(MODEL_ID, **kwargs)
    elif "flux" in lower_id:
        pipe = FluxPipeline.from_pretrained(MODEL_ID, **kwargs)
    else:
        pipe = AutoPipelineForText2Image.from_pretrained(MODEL_ID, **kwargs)

    # Strip any residual checker references
    if hasattr(pipe, "safety_checker"):
        pipe.safety_checker = None
    if hasattr(pipe, "feature_extractor"):
        pipe.feature_extractor = None

    pipe = pipe.to(DEVICE)

    # Optional LoRA steering hook (no filter; user-supplied weights)
    if LORA_PATH:
        try:
            pipe.load_lora_weights(LORA_PATH, adapter_name="steer")
            pipe.set_adapters(["steer"], adapter_weights=[LORA_WEIGHT])
        except Exception as e:
            print(f"[lora] load failed: {e}")

    if DEVICE == "cuda":
        try:
            pipe.enable_model_cpu_offload()
        except Exception:
            pipe.to("cuda")
        try:
            pipe.enable_vae_slicing()
        except Exception:
            pass

    return pipe


class GenRequest(BaseModel):
    prompt: str
    negative: str = ""
    width: int = 768
    height: int = 768
    seed: Optional[int] = None
    model: Optional[str] = None
    steps: Optional[int] = None
    guidance: Optional[float] = None


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "model": MODEL_ID,
        "device": DEVICE,
        "lora": LORA_PATH or None,
        "loaded": pipe is not None,
    }


@app.post("/api/generate")
def generate(req: GenRequest):
    if not req.prompt or not req.prompt.strip():
        raise HTTPException(status_code=400, detail="empty prompt")

    # Snap dimensions to multiples of 8, clamped to model-friendly bounds
    w = max(256, min(1536, (req.width // 8) * 8))
    h = max(256, min(1536, (req.height // 8) * 8))

    seed = req.seed if req.seed is not None else random.randint(0, 2**32 - 1)
    generator = torch.Generator(device=DEVICE).manual_seed(seed)

    p = load_pipeline()
    lower_id = MODEL_ID.lower()
    is_flux = "flux" in lower_id
    is_turbo = "turbo" in lower_id

    steps = req.steps or (4 if is_turbo else 28 if is_flux else 30)
    guidance = (
        req.guidance
        if req.guidance is not None
        else (0.0 if is_turbo else 3.5 if is_flux else 7.0)
    )

    call_kwargs = dict(
        prompt=req.prompt,
        width=w,
        height=h,
        num_inference_steps=steps,
        generator=generator,
        guidance_scale=guidance,
    )
    if not is_flux:
        call_kwargs["negative_prompt"] = req.negative or None

    with torch.inference_mode():
        result = p(**call_kwargs)

    img = result.images[0]
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()

    return {
        "url": f"data:image/png;base64,{b64}",
        "seed": seed,
        "width": w,
        "height": h,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
