import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  app.get('/api/health', async (_req, res) => {
    const customHealth = process.env.CUSTOM_HEALTH;
    if (customHealth) {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 3000);
      try {
        const r = await fetch(customHealth, { signal: controller.signal });
        const text = await r.text();
        res.status(r.status).type(r.headers.get('content-type') || 'application/json').send(text);
        return;
      } catch {
        // Fallback if backend is still booting
      } finally {
        clearTimeout(t);
      }
    }
    res.json({
      ok: true,
      backends: ['pollinations', 'local-mock', 'custom-http'],
    });
  });

  // ---- health probe passthrough (GET & POST) ----
  app.get('/api/health/custom', async (req, res) => {
    const queryTarget = typeof req.query.endpoint === 'string' ? req.query.endpoint.trim() : '';
    const rawTarget = queryTarget || process.env.CUSTOM_HEALTH || 'http://localhost:8000/api/health';

    let target = rawTarget;
    try {
      const parsed = new URL(rawTarget);
      if (!parsed.pathname.endsWith('/health')) {
        target = `${parsed.origin}/api/health`;
      }
    } catch {
      res.status(400).json({ ok: false, error: 'invalid health target URL' });
      return;
    }

    try {
      const r = await fetch(target);
      const text = await r.text();
      res.status(r.status).type(r.headers.get('content-type') || 'application/json').send(text);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(502).json({ ok: false, error: `health probe failed: ${message}` });
    }
  });

  app.post('/api/health/custom', async (req, res) => {
    const body = (req.body ?? {}) as { endpoint?: string; endpointUrl?: string; authHeader?: string };
    const rawTarget =
      (typeof body.endpoint === 'string' && body.endpoint.trim()) ||
      (typeof body.endpointUrl === 'string' && body.endpointUrl.trim()) ||
      process.env.CUSTOM_HEALTH ||
      'http://localhost:8000/api/health';

    let target = rawTarget;
    try {
      const parsed = new URL(rawTarget);
      target = `${parsed.origin}/api/health`;
    } catch {
      res.status(400).json({ ok: false, error: 'invalid endpoint URL' });
      return;
    }

    const headers: Record<string, string> = {};
    if (typeof body.authHeader === 'string' && body.authHeader.trim()) {
      headers['Authorization'] = body.authHeader.trim();
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    try {
      const upstream = await fetch(target, { headers, signal: controller.signal });
      const text = await upstream.text();
      res.status(upstream.status).type(upstream.headers.get('content-type') || 'application/json').send(text);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(502).json({ ok: false, error: `health probe failed: ${message}` });
    } finally {
      clearTimeout(timeoutId);
    }
  });

  // ---- custom-http proxy: body passes through untouched ----
  app.post('/api/generate/custom', async (req, res) => {
    const body = (req.body ?? {}) as Record<string, unknown>;
    const target =
      (typeof body.endpoint === 'string' && body.endpoint.trim()) ||
      (typeof body.endpointUrl === 'string' && body.endpointUrl.trim()) ||
      process.env.CUSTOM_ENDPOINT ||
      'http://localhost:8000/api/generate';

    const {
      endpoint: _dropEndpoint,
      endpointUrl: _dropEndpointUrl,
      authHeader,
      headers: callerHeaders,
      ...payload
    } = body;

    // Only reject an empty prompt
    if (!payload?.prompt || typeof payload.prompt !== 'string' || !payload.prompt.trim()) {
      res.status(400).json({ error: 'empty prompt' });
      return;
    }

    const headers: Record<string, string> = {
      'content-type': 'application/json',
      ...(typeof callerHeaders === 'object' && callerHeaders !== null
        ? (callerHeaders as Record<string, string>)
        : {}),
    };
    if (typeof authHeader === 'string' && authHeader.trim()) {
      headers['Authorization'] = authHeader.trim();
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 180000);

    try {
      const upstream = await fetch(target, {
        method: 'POST',
        headers,
        signal: controller.signal,
        body: JSON.stringify(payload),
      });

      const contentType = upstream.headers.get('content-type') || 'application/json';
      if (upstream.ok && contentType.startsWith('image/')) {
        const buf = Buffer.from(await upstream.arrayBuffer());
        res.json({
          url: `data:${contentType.split(';')[0]};base64,${buf.toString('base64')}`,
          seed: payload.seed ?? 0,
          width: payload.width,
          height: payload.height,
        });
        return;
      }

      const text = await upstream.text();
      res.status(upstream.status).type(contentType).send(text);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(502).json({ error: `upstream failed: ${message}` });
    } finally {
      clearTimeout(timeoutId);
    }
  });

  // ---- pollinations proxy: pass the query verbatim ----
  app.post('/api/generate/pollinations', async (req, res) => {
    const {
      prompt = '',
      negative = '',
      width = 768,
      height = 768,
      seed,
      model = 'flux',
    } = (req.body ?? {}) as {
      prompt?: string;
      negative?: string;
      width?: number;
      height?: number;
      seed?: number;
      model?: string;
    };

    if (typeof prompt !== 'string' || !prompt.trim()) {
      res.status(400).json({ error: 'empty prompt' });
      return;
    }

    const full = negative ? `${prompt} | avoid: ${negative}` : prompt;
    const s =
      typeof seed === 'number' && Number.isFinite(seed)
        ? Math.floor(Math.abs(seed))
        : Math.floor(Math.random() * 1_000_000_000);

    const targetUrl = new URL(`https://image.pollinations.ai/prompt/${encodeURIComponent(full)}`);
    targetUrl.searchParams.set('width', String(width));
    targetUrl.searchParams.set('height', String(height));
    targetUrl.searchParams.set('seed', String(s));
    targetUrl.searchParams.set('model', model || 'flux');
    targetUrl.searchParams.set('nologo', 'true');
    targetUrl.searchParams.set('enhance', 'false');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 50000);

    try {
      const r = await fetch(targetUrl.toString(), { signal: controller.signal });
      if (!r.ok) {
        let detail = '';
        try {
          const text = await r.text();
          const parsed = JSON.parse(text) as { error?: { message?: string } | string };
          if (typeof parsed.error === 'string') detail = parsed.error;
          else if (parsed.error?.message) detail = parsed.error.message;
          else if (text) detail = text.slice(0, 140);
        } catch {
          // ignore parse error
        }
        res.status(r.status).json({
          error: `pollinations ${r.status}${detail ? `: ${detail}` : ''}`,
        });
        return;
      }
      const contentType = r.headers.get('content-type') || 'image/jpeg';
      if (!contentType.startsWith('image/')) {
        res.status(502).json({ error: `unexpected upstream content-type: ${contentType}` });
        return;
      }
      const buf = Buffer.from(await r.arrayBuffer());
      res.json({
        url: `data:${contentType.split(';')[0]};base64,${buf.toString('base64')}`,
        seed: s,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(502).json({ error: `pollinations failed: ${message}` });
    } finally {
      clearTimeout(timeoutId);
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Image Forge server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Image Forge server:', err);
  process.exit(1);
});
