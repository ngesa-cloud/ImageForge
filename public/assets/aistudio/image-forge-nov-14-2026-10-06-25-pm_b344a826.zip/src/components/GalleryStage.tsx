import {
  AlertCircle,
  ArrowUpRight,
  Check,
  Copy,
  Download,
  Image as ImageIcon,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { useState } from 'react';
import type { BackendId, GeneratedCard } from '../types/forge';
import { STARTER_PROMPTS } from '../lib/presets';

interface GalleryStageProps {
  cards: GeneratedCard[];
  backendId: BackendId;
  onSelectCard: (card: GeneratedCard) => void;
  onDownloadCard: (card: GeneratedCard) => void;
  onReuseCard: (card: GeneratedCard) => void;
  onRetryCard: (card: GeneratedCard) => void;
  onRemoveCard: (id: string) => void;
  onClearAll: () => void;
  onApplyStarter: (starter: (typeof STARTER_PROMPTS)[number], autoRun: boolean) => void;
  onSwitchToLocalMock: () => void;
}

const BACKEND_LABELS: Record<BackendId, string> = {
  auto: 'Auto (Fallback Chain)',
  pollinations: 'Pollinations (Keyless)',
  'local-mock': 'Local Mock (Zero-Key)',
  'custom-http': 'Local GPU / HTTP',
};

export function GalleryStage({
  cards,
  backendId,
  onSelectCard,
  onDownloadCard,
  onReuseCard,
  onRetryCard,
  onRemoveCard,
  onClearAll,
  onApplyStarter,
  onSwitchToLocalMock,
}: GalleryStageProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  const handleCopySeed = (card: GeneratedCard) => {
    navigator.clipboard?.writeText(String(card.seed));
    setCopiedId(card.id);
    setTimeout(() => {
      setCopiedId((prev) => (prev === card.id ? null : prev));
    }, 1500);
  };

  const readyCount = cards.filter((c) => c.status === 'ready').length;

  return (
    <section className="flex-1 min-w-0 min-h-0 flex flex-col bg-[#0C0E12]">
      {/* Stage utility header */}
      <div className="px-6 py-3.5 border-b border-[#252A35] flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3 text-xs text-[#8F98A8]">
          <span className="font-medium text-[#ECEEF2] tabular-nums">
            {cards.length === 0
              ? 'Gallery'
              : `${readyCount} of ${cards.length} rendered`}
          </span>
          <span aria-hidden="true">·</span>
          <span>Backend: {BACKEND_LABELS[backendId]}</span>
        </div>

        {cards.length > 0 && (
          <button
            type="button"
            onClick={onClearAll}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#8F98A8] hover:text-[#ECEEF2] bg-[#14171E] border border-[#252A35] rounded-lg hover:border-[#3A4254] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5]"
          >
            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
            Clear All
          </button>
        )}
      </div>

      {/* Main scrollable stage */}
      <div className="flex-1 overflow-y-auto p-6">
        {cards.length === 0 ? (
          <div className="h-full min-h-[420px] flex flex-col items-center justify-center max-w-3xl mx-auto">
            <div className="w-12 h-12 rounded-xl bg-[#14171E] border border-[#252A35] flex items-center justify-center mb-5">
              <ImageIcon className="w-5 h-5 text-[#8F98A8]" aria-hidden="true" />
            </div>
            <h2 className="font-display text-xl font-semibold text-[#ECEEF2] text-center text-balance">
              Describe a scene to begin rendering
            </h2>
            <p className="mt-2 text-sm text-[#8F98A8] text-center max-w-md">
              Enter a prompt on the left, adjust dimensions or style modifiers, or start from one of these curated studies.
            </p>

            <div className="mt-8 w-full grid grid-cols-1 md:grid-cols-2 gap-3">
              {STARTER_PROMPTS.map((item) => (
                <div
                  key={item.title}
                  className="bg-[#14171E] border border-[#252A35] rounded-xl p-4 flex flex-col justify-between gap-3 hover:border-[#3A4254] transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-sm font-semibold text-[#ECEEF2]">{item.title}</h3>
                      <span className="text-xs font-mono tabular-nums text-[#6E7787]">
                        {item.width}×{item.height}
                      </span>
                    </div>
                    <p className="mt-1.5 text-xs text-[#8F98A8] line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => onApplyStarter(item, true)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#4F6DF5] hover:bg-[#415EE6] rounded-md transition-colors whitespace-nowrap"
                    >
                      Generate Sample
                      <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onApplyStarter(item, false)}
                      className="px-3 py-1.5 text-xs font-medium text-[#8F98A8] hover:text-[#ECEEF2] bg-[#0C0E12] border border-[#252A35] rounded-md transition-colors whitespace-nowrap"
                    >
                      Load Prompt
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5 items-start">
            {cards.map((card) => {
              const hasBrokenImg = Boolean(brokenImages[card.id]);
              return (
                <article
                  key={card.id}
                  className="bg-[#14171E] border border-[#252A35] rounded-xl overflow-hidden flex flex-col"
                >
                  {/* Image frame */}
                  <div
                    className="relative w-full bg-[#0C0E12] overflow-hidden"
                    style={{ aspectRatio: `${card.width} / ${card.height}` }}
                  >
                    {card.status === 'pending' && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-4 text-center">
                        <div className="w-7 h-7 rounded-full border-2 border-[#252A35] border-t-[#4F6DF5] animate-spin" />
                        <div className="space-y-1">
                          <p className="text-xs font-medium text-[#ECEEF2]">Rendering image</p>
                          <p className="text-xs font-mono tabular-nums text-[#6E7787]">
                            {card.width}×{card.height} · seed {card.seed}
                          </p>
                        </div>
                      </div>
                    )}

                    {card.status === 'error' && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-5 text-center bg-[#181216] overflow-y-auto">
                        <AlertCircle className="w-6 h-6 text-[#DC2626] shrink-0" aria-hidden="true" />
                        <div className="space-y-1 max-w-xs">
                          <p className="text-xs font-semibold text-[#FCA5A5]">Generation Failed</p>
                          <p className="text-[11px] text-[#CBD5E1] break-words leading-relaxed">
                            {card.error || 'Unknown backend error'}
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => onRetryCard(card)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#ECEEF2] bg-[#14171E] border border-[#252A35] rounded-lg hover:border-[#3A4254] transition-colors"
                          >
                            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                            Retry
                          </button>
                          {card.backend !== 'local-mock' && (
                            <button
                              type="button"
                              onClick={onSwitchToLocalMock}
                              className="px-3 py-1.5 text-xs font-medium text-[#8F98A8] hover:text-[#ECEEF2] bg-[#14171E] border border-[#252A35] rounded-lg hover:border-[#3A4254] transition-colors"
                            >
                              Use Local Mock
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {card.status === 'ready' && card.url && !hasBrokenImg && (
                      <button
                        type="button"
                        onClick={() => onSelectCard(card)}
                        aria-label={`Inspect generated image for ${card.basePrompt}`}
                        className="block w-full h-full cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#4F6DF5]"
                      >
                        <img
                          src={card.url}
                          alt={card.basePrompt}
                          referrerPolicy="no-referrer"
                          loading="lazy"
                          onError={() =>
                            setBrokenImages((prev) => ({ ...prev, [card.id]: true }))
                          }
                          className="w-full h-full object-cover block"
                        />
                      </button>
                    )}

                    {card.status === 'ready' && (!card.url || hasBrokenImg) && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-4 text-center bg-[#14171E]">
                        <ImageIcon className="w-6 h-6 text-[#6E7787]" aria-hidden="true" />
                        <p className="text-xs text-[#8F98A8] line-clamp-2 max-w-[22ch]">
                          {card.basePrompt}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Card metadata & actions */}
                  <div className="p-3.5 border-t border-[#252A35] space-y-2.5">
                    <div>
                      <p
                        title={card.fullPrompt}
                        className="text-xs font-medium text-[#ECEEF2] truncate"
                      >
                        {card.basePrompt}
                      </p>
                      <div className="mt-1 flex items-center gap-1.5 text-[11px] text-[#8F98A8] font-mono tabular-nums truncate">
                        <span>
                          {card.width}×{card.height}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{card.model}</span>
                        {card.provider && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{card.provider}</span>
                          </>
                        )}
                        <span aria-hidden="true">·</span>
                        <span>seed {card.seed}</span>
                        {typeof card.durationMs === 'number' && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{(card.durationMs / 1000).toFixed(1)}s</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-0.5">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          disabled={card.status !== 'ready'}
                          onClick={() => onDownloadCard(card)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#ECEEF2] bg-[#0C0E12] border border-[#252A35] rounded-md hover:border-[#3A4254] disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
                        >
                          <Download className="w-3 h-3" aria-hidden="true" />
                          Download
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCopySeed(card)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#8F98A8] hover:text-[#ECEEF2] bg-[#0C0E12] border border-[#252A35] rounded-md hover:border-[#3A4254] transition-colors whitespace-nowrap"
                        >
                          {copiedId === card.id ? (
                            <>
                              <Check className="w-3 h-3 text-[#16A34A]" aria-hidden="true" />
                              Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" aria-hidden="true" />
                              Seed
                            </>
                          )}
                        </button>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onReuseCard(card)}
                          title="Load prompt and seed into controls"
                          className="px-2.5 py-1.5 text-xs font-medium text-[#8F98A8] hover:text-[#ECEEF2] rounded-md hover:bg-[#1B1F29] transition-colors whitespace-nowrap"
                        >
                          Reuse
                        </button>
                        <button
                          type="button"
                          onClick={() => onRemoveCard(card.id)}
                          aria-label="Remove image from gallery"
                          className="p-1.5 text-[#6E7787] hover:text-[#DC2626] rounded-md hover:bg-[#1B1F29] transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
