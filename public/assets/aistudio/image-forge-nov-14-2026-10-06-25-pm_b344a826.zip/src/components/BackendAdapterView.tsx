import { Activity, AlertCircle, Check, Copy, Download, Play } from 'lucide-react';
import { useState } from 'react';
import type { BackendConfig, BackendId, CustomHealthResult } from '../types/forge';
import {
  ADAPTER_CONTRACT_SNIPPET,
  DOCKER_COMPOSE_SNIPPET,
  FASTAPI_DIFFUSERS_SHIM,
  buildSingleFileHtml,
  checkCustomBackendHealth,
  generate,
} from '../lib/imageBackend';
import { MODELS_BY_BACKEND } from '../lib/presets';

interface BackendAdapterViewProps {
  config: BackendConfig;
  onChangeConfig: (next: BackendConfig) => void;
  onExportHtml: () => void;
}

type CodeTab = 'fastapi' | 'compose' | 'adapter' | 'html';

export function BackendAdapterView({
  config,
  onChangeConfig,
  onExportHtml,
}: BackendAdapterViewProps) {
  const [codeTab, setCodeTab] = useState<CodeTab>('fastapi');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [healthState, setHealthState] = useState<{
    checking: boolean;
    result?: CustomHealthResult;
  }>({ checking: false });
  const [testState, setTestState] = useState<{
    running: boolean;
    resultUrl?: string;
    durationMs?: number;
    error?: string;
  }>({ running: false });

  const activeCode =
    codeTab === 'fastapi'
      ? FASTAPI_DIFFUSERS_SHIM
      : codeTab === 'compose'
        ? DOCKER_COMPOSE_SNIPPET
        : codeTab === 'adapter'
          ? ADAPTER_CONTRACT_SNIPPET
          : buildSingleFileHtml(config);

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1600);
  };

  const handleDownloadText = (filename: string, content: string, type = 'text/plain') => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1200);
  };

  const handleHealthCheck = async () => {
    setHealthState({ checking: true });
    const result = await checkCustomBackendHealth(config);
    setHealthState({ checking: false, result });
  };

  const handleRunTest = async () => {
    setTestState({ running: true });
    try {
      const defaultModel = MODELS_BY_BACKEND[config.id][0]?.id ?? 'default';
      const res = await generate(
        {
          prompt: 'minimalist basalt arch at twilight, calm sea, 35mm photography',
          negativePrompt: 'blurry, text',
          width: 512,
          height: 512,
          seed: 424242,
          model: defaultModel,
        },
        config
      );
      setTestState({
        running: false,
        resultUrl: res.url,
        durationMs: res.durationMs,
      });
    } catch (err) {
      setTestState({
        running: false,
        error: err instanceof Error ? err.message : 'Test request failed.',
      });
    }
  };

  const selectBackend = (id: BackendId) => {
    onChangeConfig({ ...config, id });
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0C0E12] p-6 lg:p-10">
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#ECEEF2] text-balance">
            Drop-in Backend Adapter
          </h1>
          <p className="mt-2 text-sm text-[#8F98A8] max-w-2xl leading-relaxed">
            Every prompt passes through{' '}
            <code className="font-mono text-xs text-[#ECEEF2] bg-[#14171E] px-1.5 py-0.5 rounded border border-[#252A35]">
              generate(params)
            </code>{' '}
            unchanged with zero client-side filtering. Point at the included FastAPI +{' '}
            <code className="font-mono text-xs text-[#ECEEF2] bg-[#14171E] px-1.5 py-0.5 rounded border border-[#252A35]">
              diffusers
            </code>{' '}
            server (<code className="font-mono text-xs text-[#ECEEF2]">backend/server.py</code>) to run any local SD, SDXL, or Flux checkpoint with{' '}
            <code className="font-mono text-xs text-[#ECEEF2]">safety_checker=None</code>.
          </p>
        </div>

        {/* Backend configuration & live contract test */}
        <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-6 items-start">
          <div className="bg-[#14171E] border border-[#252A35] rounded-xl p-5 space-y-5">
            <div>
              <h2 className="text-sm font-semibold text-[#ECEEF2]">Active Provider</h2>
              <p className="text-xs text-[#8F98A8] mt-1">
                Select how the Studio resolves image requests.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
              {(
                [
                  {
                    id: 'auto',
                    title: 'Auto Chain',
                    desc: 'Local GPU -> Airforce -> Pollinations',
                  },
                  {
                    id: 'pollinations',
                    title: 'Pollinations',
                    desc: 'Keyless public image backend',
                  },
                  {
                    id: 'local-mock',
                    title: 'Local Mock',
                    desc: 'Zero-key deterministic canvas',
                  },
                  {
                    id: 'custom-http',
                    title: 'Local GPU / HTTP',
                    desc: 'Unfiltered FastAPI diffusers',
                  },
                ] as const
              ).map((item) => {
                const active = config.id === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => selectBackend(item.id)}
                    className={`p-3 text-left rounded-lg border transition-colors ${
                      active
                        ? 'bg-[#4F6DF5]/15 border-[#4F6DF5]'
                        : 'bg-[#0C0E12] border-[#252A35] hover:border-[#3A4254]'
                    }`}
                  >
                    <div className="text-xs font-semibold text-[#ECEEF2]">{item.title}</div>
                    <div className="text-[11px] text-[#8F98A8] mt-1">{item.desc}</div>
                  </button>
                );
              })}
            </div>

            {(config.id === 'custom-http' || config.id === 'auto') && (
              <div className="space-y-3 pt-3 border-t border-[#252A35]">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label
                      htmlFor="custom-endpoint"
                      className="text-xs font-medium text-[#8F98A8]"
                    >
                      Endpoint URL (POST JSON)
                    </label>
                    <button
                      type="button"
                      onClick={handleHealthCheck}
                      disabled={healthState.checking}
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-[#8F98A8] hover:text-[#ECEEF2] transition-colors"
                    >
                      <Activity className="w-3.5 h-3.5" aria-hidden="true" />
                      {healthState.checking ? 'Checking...' : 'Check /api/health'}
                    </button>
                  </div>
                  <input
                    id="custom-endpoint"
                    type="url"
                    value={config.customEndpointUrl}
                    onChange={(e) =>
                      onChangeConfig({ ...config, customEndpointUrl: e.target.value })
                    }
                    placeholder="http://localhost:8000/api/generate"
                    className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
                  />
                  {healthState.result && (
                    <div className="mt-2 text-xs font-mono">
                      {healthState.result.ok ? (
                        <span className="text-[#4ADE80]">
                          OK · model={healthState.result.model ?? 'unknown'} · device=
                          {healthState.result.device ?? 'unknown'} · loaded=
                          {String(Boolean(healthState.result.loaded))}
                        </span>
                      ) : (
                        <span className="text-[#FCA5A5]">
                          Offline · {healthState.result.error || 'Health check failed'}
                        </span>
                      )}
                    </div>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="custom-auth"
                    className="block text-xs font-medium text-[#8F98A8] mb-1.5"
                  >
                    Optional Authorization Header
                  </label>
                  <input
                    id="custom-auth"
                    type="password"
                    value={config.customAuthHeader}
                    onChange={(e) =>
                      onChangeConfig({ ...config, customAuthHeader: e.target.value })
                    }
                    placeholder="Bearer ..."
                    className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
                  />
                </div>
              </div>
            )}

            {config.id !== 'local-mock' && (
              <div className="flex items-center justify-between gap-4 pt-3 border-t border-[#252A35]">
                <div>
                  <div className="text-xs font-medium text-[#ECEEF2]">Route via Express Proxy</div>
                  <div className="text-[11px] text-[#8F98A8]">
                    Forwards requests through this server, or switch to Direct Fetch for localhost GPU boxes.
                  </div>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={config.useServerProxy}
                  onClick={() =>
                    onChangeConfig({ ...config, useServerProxy: !config.useServerProxy })
                  }
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                    config.useServerProxy
                      ? 'bg-[#4F6DF5]/15 border-[#4F6DF5] text-[#ECEEF2]'
                      : 'bg-[#0C0E12] border-[#252A35] text-[#8F98A8]'
                  }`}
                >
                  {config.useServerProxy ? 'Proxy On' : 'Direct Fetch'}
                </button>
              </div>
            )}
          </div>

          {/* Live Contract Test */}
          <div className="bg-[#14171E] border border-[#252A35] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-[#ECEEF2]">Contract Probe</h2>
                <p className="text-xs text-[#8F98A8] mt-0.5">
                  Verifies 512×512 output from <span className="font-mono">{config.id}</span>.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRunTest}
                disabled={testState.running}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#4F6DF5] hover:bg-[#415EE6] disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <Play className="w-3.5 h-3.5" aria-hidden="true" />
                {testState.running ? 'Running...' : 'Test Generate'}
              </button>
            </div>

            <div className="aspect-square max-h-[220px] w-full bg-[#0C0E12] border border-[#252A35] rounded-lg overflow-hidden flex items-center justify-center">
              {testState.running ? (
                <div className="flex flex-col items-center gap-2 text-xs text-[#8F98A8]">
                  <div className="w-6 h-6 rounded-full border-2 border-[#252A35] border-t-[#4F6DF5] animate-spin" />
                  <span>Calling generate()...</span>
                </div>
              ) : testState.error ? (
                <div className="p-4 text-center space-y-1.5">
                  <AlertCircle className="w-5 h-5 text-[#DC2626] mx-auto" aria-hidden="true" />
                  <p className="text-xs text-[#FCA5A5]">{testState.error}</p>
                </div>
              ) : testState.resultUrl ? (
                <img
                  src={testState.resultUrl}
                  alt="Backend contract test output"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <p className="text-xs text-[#6E7787]">No test run yet</p>
              )}
            </div>

            {typeof testState.durationMs === 'number' && !testState.error && (
              <div className="flex items-center justify-between text-xs text-[#8F98A8] font-mono tabular-nums">
                <span className="text-[#4ADE80]">OK · {`{ url, seed: 424242 }`}</span>
                <span>{(testState.durationMs / 1000).toFixed(2)}s</span>
              </div>
            )}
          </div>
        </div>

        {/* Code & Export Tabs */}
        <div className="bg-[#14171E] border border-[#252A35] rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-[#252A35] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1 p-1 bg-[#0C0E12] rounded-lg border border-[#252A35]">
              {(
                [
                  { id: 'fastapi', label: 'Unfiltered FastAPI (server.py)' },
                  { id: 'compose', label: 'docker-compose.yml' },
                  { id: 'adapter', label: 'generate() Adapter' },
                  { id: 'html', label: 'Single-File index.html' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setCodeTab(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    codeTab === tab.id
                      ? 'bg-[#1B1F29] text-[#ECEEF2]'
                      : 'text-[#8F98A8] hover:text-[#ECEEF2]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleCopy(codeTab, activeCode)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#ECEEF2] bg-[#0C0E12] border border-[#252A35] rounded-lg hover:border-[#3A4254] transition-colors whitespace-nowrap"
              >
                {copiedKey === codeTab ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#16A34A]" aria-hidden="true" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                    Copy Code
                  </>
                )}
              </button>

              {codeTab === 'fastapi' && (
                <button
                  type="button"
                  onClick={() =>
                    handleDownloadText('server.py', FASTAPI_DIFFUSERS_SHIM, 'text/x-python')
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#4F6DF5] hover:bg-[#415EE6] rounded-lg transition-colors whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  Download server.py
                </button>
              )}

              {codeTab === 'compose' && (
                <button
                  type="button"
                  onClick={() =>
                    handleDownloadText('docker-compose.yml', DOCKER_COMPOSE_SNIPPET, 'text/yaml')
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#4F6DF5] hover:bg-[#415EE6] rounded-lg transition-colors whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  Download docker-compose.yml
                </button>
              )}

              {codeTab === 'html' && (
                <button
                  type="button"
                  onClick={onExportHtml}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#4F6DF5] hover:bg-[#415EE6] rounded-lg transition-colors whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  Download index.html
                </button>
              )}
            </div>
          </div>

          <pre className="p-5 overflow-x-auto text-xs font-mono leading-relaxed text-[#CBD5E1] max-h-[460px]">
            <code>{activeCode}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
