import { Download } from 'lucide-react';

export type WorkspaceTab = 'studio' | 'adapter';

interface TopBarProps {
  activeTab: WorkspaceTab;
  onTabChange: (tab: WorkspaceTab) => void;
  onExportHtml: () => void;
}

export function TopBar({ activeTab, onTabChange, onExportHtml }: TopBarProps) {
  return (
    <header className="h-14 border-b border-[#252A35] bg-[#0C0E12] px-6 flex items-center justify-between gap-8 shrink-0">
      {/* Zone 1: Single-line brand wordmark */}
      <button
        type="button"
        onClick={() => onTabChange('studio')}
        className="font-display text-[17px] font-semibold tracking-tight text-[#ECEEF2] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] rounded"
      >
        Image Forge
      </button>

      {/* Zone 2: Clean single-line text navigation tabs */}
      <nav aria-label="Workspace navigation" className="flex items-center gap-6">
        <button
          type="button"
          onClick={() => onTabChange('studio')}
          className={`relative py-4 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] rounded ${
            activeTab === 'studio'
              ? 'text-[#ECEEF2]'
              : 'text-[#8F98A8] hover:text-[#ECEEF2]'
          }`}
        >
          Studio
          {activeTab === 'studio' && (
            <span
              aria-hidden="true"
              className="absolute inset-x-0 bottom-0 h-[2px] bg-[#4F6DF5]"
            />
          )}
        </button>
        <button
          type="button"
          onClick={() => onTabChange('adapter')}
          className={`relative py-4 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] rounded ${
            activeTab === 'adapter'
              ? 'text-[#ECEEF2]'
              : 'text-[#8F98A8] hover:text-[#ECEEF2]'
          }`}
        >
          Backend Adapter
          {activeTab === 'adapter' && (
            <span
              aria-hidden="true"
              className="absolute inset-x-0 bottom-0 h-[2px] bg-[#4F6DF5]"
            />
          )}
        </button>
      </nav>

      {/* Zone 3: Primary action */}
      <div className="flex items-center shrink-0">
        <button
          type="button"
          onClick={onExportHtml}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-[#ECEEF2] bg-[#14171E] border border-[#252A35] rounded-lg hover:border-[#3A4254] hover:bg-[#1B1F29] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5]"
        >
          <Download className="w-3.5 h-3.5 text-[#8F98A8]" aria-hidden="true" />
          Export HTML
        </button>
      </div>
    </header>
  );
}
