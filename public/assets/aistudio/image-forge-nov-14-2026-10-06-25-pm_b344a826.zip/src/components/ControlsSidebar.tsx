import { Shuffle, Sparkles, Eraser } from 'lucide-react';
import type { BackendId } from '../types/forge';
import {
  ASPECT_PRESETS,
  MODELS_BY_BACKEND,
  STARTER_PROMPTS,
  STYLE_PRESETS,
  clampDimension,
} from '../lib/presets';

interface ControlsSidebarProps {
  prompt: string;
  onPromptChange: (val: string) => void;
  negativePrompt: string;
  onNegativePromptChange: (val: string) => void;
  selectedStyleIds: string[];
  onToggleStyle: (id: string) => void;
  width: number;
  height: number;
  onDimensionsChange: (w: number, h: number) => void;
  batchCount: number;
  onBatchCountChange: (count: number) => void;
  seedInput: string;
  onSeedInputChange: (seed: string) => void;
  backendId: BackendId;
  onBackendIdChange: (id: BackendId) => void;
  model: string;
  onModelChange: (model: string) => void;
  stepsInput: string;
  onStepsInputChange: (val: string) => void;
  guidanceInput: string;
  onGuidanceInputChange: (val: string) => void;
  customEndpointUrl: string;
  onCustomEndpointUrlChange: (url: string) => void;
  isGenerating: boolean;
  progressText: string;
  onGenerate: () => void;
}

export function ControlsSidebar({
  prompt,
  onPromptChange,
  negativePrompt,
  onNegativePromptChange,
  selectedStyleIds,
  onToggleStyle,
  width,
  height,
  onDimensionsChange,
  batchCount,
  onBatchCountChange,
  seedInput,
  onSeedInputChange,
  backendId,
  onBackendIdChange,
  model,
  onModelChange,
  stepsInput,
  onStepsInputChange,
  guidanceInput,
  onGuidanceInputChange,
  customEndpointUrl,
  onCustomEndpointUrlChange,
  isGenerating,
  progressText,
  onGenerate,
}: ControlsSidebarProps) {
  const models = MODELS_BY_BACKEND[backendId];

  const handleRandomPrompt = () => {
    const others = STARTER_PROMPTS.filter((p) => p.prompt !== prompt.trim());
    const pick = others[Math.floor(Math.random() * others.length)] ?? STARTER_PROMPTS[0];
    onPromptChange(pick.prompt);
    onNegativePromptChange(pick.negative);
  };

  const handleRandomSeed = () => {
    onSeedInputChange(String(Math.floor(Math.random() * 1_000_000_000)));
  };

  return (
    <aside className="w-full lg:w-[376px] shrink-0 bg-[#14171E] border-b lg:border-b-0 lg:border-r border-[#252A35] flex flex-col min-h-0">
      <div className="p-5 space-y-5 overflow-y-auto flex-1">
        {/* Prompt */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="prompt-input" className="text-xs font-medium text-[#8F98A8]">
              Prompt
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleRandomPrompt}
                className="inline-flex items-center gap-1 text-xs text-[#8F98A8] hover:text-[#ECEEF2] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] rounded px-1.5 py-0.5"
              >
                <Sparkles className="w-3 h-3" aria-hidden="true" />
                Sample
              </button>
              {prompt && (
                <button
                  type="button"
                  onClick={() => onPromptChange('')}
                  aria-label="Clear prompt"
                  className="inline-flex items-center gap-1 text-xs text-[#8F98A8] hover:text-[#ECEEF2] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] rounded px-1.5 py-0.5"
                >
                  <Eraser className="w-3 h-3" aria-hidden="true" />
                  Clear
                </button>
              )}
            </div>
          </div>
          <textarea
            id="prompt-input"
            rows={4}
            value={prompt}
            onChange={(e) => onPromptChange(e.target.value)}
            onKeyDown={(e) => {
              if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                onGenerate();
              }
            }}
            placeholder="a basalt lighthouse at dusk, cold Atlantic mist, warm amber beacon, 35mm film grain"
            className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2.5 text-sm text-[#ECEEF2] placeholder:text-[#565E6E] focus:outline-none focus:border-[#4F6DF5] transition-colors resize-y min-h-[104px]"
          />
        </div>

        {/* Negative prompt */}
        <div>
          <label htmlFor="negative-input" className="block text-xs font-medium text-[#8F98A8] mb-2">
            Negative Prompt
          </label>
          <textarea
            id="negative-input"
            rows={2}
            value={negativePrompt}
            onChange={(e) => onNegativePromptChange(e.target.value)}
            placeholder="blurry, watermark, text, extra fingers"
            className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm text-[#ECEEF2] placeholder:text-[#565E6E] focus:outline-none focus:border-[#4F6DF5] transition-colors resize-y min-h-[64px]"
          />
        </div>

        {/* Style Presets */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-[#8F98A8]">Style Presets</span>
            {selectedStyleIds.length > 0 && (
              <button
                type="button"
                onClick={() => selectedStyleIds.forEach(onToggleStyle)}
                className="text-xs text-[#8F98A8] hover:text-[#ECEEF2] transition-colors"
              >
                Reset ({selectedStyleIds.length})
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {STYLE_PRESETS.map((preset) => {
              const active = selectedStyleIds.includes(preset.id);
              return (
                <button
                  key={preset.id}
                  type="button"
                  aria-pressed={active}
                  title={preset.description}
                  onClick={() => onToggleStyle(preset.id)}
                  className={`px-3 py-2 text-xs font-medium text-left rounded-lg border transition-colors whitespace-nowrap truncate focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] ${
                    active
                      ? 'bg-[#4F6DF5]/15 border-[#4F6DF5] text-[#ECEEF2]'
                      : 'bg-[#0C0E12] border-[#252A35] text-[#8F98A8] hover:text-[#ECEEF2] hover:border-[#3A4254]'
                  }`}
                >
                  {preset.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Aspect Ratio & Dimensions */}
        <div>
          <span className="block text-xs font-medium text-[#8F98A8] mb-2">
            Aspect Ratio & Dimensions
          </span>
          <div className="grid grid-cols-5 gap-1.5 mb-2.5">
            {ASPECT_PRESETS.map((preset) => {
              const isSelected = preset.width === width && preset.height === height;
              return (
                <button
                  key={preset.id}
                  type="button"
                  aria-pressed={isSelected}
                  onClick={() => onDimensionsChange(preset.width, preset.height)}
                  className={`py-2 px-1 text-xs font-mono tabular-nums rounded-lg border transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4F6DF5] ${
                    isSelected
                      ? 'bg-[#4F6DF5]/15 border-[#4F6DF5] text-[#ECEEF2]'
                      : 'bg-[#0C0E12] border-[#252A35] text-[#8F98A8] hover:text-[#ECEEF2] hover:border-[#3A4254]'
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label htmlFor="width-input" className="block text-[11px] text-[#6E7787] mb-1">
                Width (px)
              </label>
              <input
                id="width-input"
                type="number"
                min={256}
                max={1536}
                step={64}
                value={width}
                onChange={(e) => onDimensionsChange(Number(e.target.value) || 768, height)}
                onBlur={() => onDimensionsChange(clampDimension(width), height)}
                className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
              />
            </div>
            <div>
              <label htmlFor="height-input" className="block text-[11px] text-[#6E7787] mb-1">
                Height (px)
              </label>
              <input
                id="height-input"
                type="number"
                min={256}
                max={1536}
                step={64}
                value={height}
                onChange={(e) => onDimensionsChange(width, Number(e.target.value) || 768)}
                onBlur={() => onDimensionsChange(width, clampDimension(height))}
                className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
              />
            </div>
          </div>
        </div>

        {/* Batch & Seed */}
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label htmlFor="batch-select" className="block text-xs font-medium text-[#8F98A8] mb-2">
              Batch Count
            </label>
            <select
              id="batch-select"
              value={batchCount}
              onChange={(e) => onBatchCountChange(Number(e.target.value))}
              className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
            >
              <option value={1}>1 image</option>
              <option value={2}>2 images</option>
              <option value={4}>4 images</option>
              <option value={6}>6 images</option>
            </select>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="seed-input" className="text-xs font-medium text-[#8F98A8]">
                Seed
              </label>
              <button
                type="button"
                onClick={handleRandomSeed}
                title="Generate random seed"
                className="inline-flex items-center gap-1 text-[11px] text-[#8F98A8] hover:text-[#ECEEF2] transition-colors"
              >
                <Shuffle className="w-3 h-3" aria-hidden="true" />
                Roll
              </button>
            </div>
            <input
              id="seed-input"
              type="number"
              min={0}
              value={seedInput}
              onChange={(e) => onSeedInputChange(e.target.value)}
              placeholder="Random"
              className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-[#ECEEF2] placeholder:text-[#565E6E] focus:outline-none focus:border-[#4F6DF5]"
            />
          </div>
        </div>

        {/* Backend & Model */}
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label htmlFor="backend-select" className="block text-xs font-medium text-[#8F98A8] mb-2">
              Backend
            </label>
            <select
              id="backend-select"
              value={backendId}
              onChange={(e) => onBackendIdChange(e.target.value as BackendId)}
              className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
            >
              <option value="auto">Auto (Fallback Chain)</option>
              <option value="pollinations">Pollinations</option>
              <option value="local-mock">Local Mock</option>
              <option value="custom-http">Local GPU / HTTP</option>
            </select>
          </div>
          <div>
            <label htmlFor="model-select" className="block text-xs font-medium text-[#8F98A8] mb-2">
              Model
            </label>
            <select
              id="model-select"
              value={model}
              onChange={(e) => onModelChange(e.target.value)}
              className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono text-[#ECEEF2] focus:outline-none focus:border-[#4F6DF5]"
            >
              {models.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {(backendId === 'custom-http' || backendId === 'auto') && (
          <>
            {backendId === 'custom-http' && (
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label htmlFor="steps-input" className="block text-xs font-medium text-[#8F98A8] mb-2">
                    Steps
                  </label>
                  <input
                    id="steps-input"
                    type="number"
                    min={1}
                    max={150}
                    value={stepsInput}
                    onChange={(e) => onStepsInputChange(e.target.value)}
                    placeholder="Auto"
                    className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-[#ECEEF2] placeholder:text-[#565E6E] focus:outline-none focus:border-[#4F6DF5]"
                  />
                </div>
                <div>
                  <label
                    htmlFor="guidance-input"
                    className="block text-xs font-medium text-[#8F98A8] mb-2"
                  >
                    Guidance Scale
                  </label>
                  <input
                    id="guidance-input"
                    type="number"
                    min={0}
                    max={30}
                    step={0.5}
                    value={guidanceInput}
                    onChange={(e) => onGuidanceInputChange(e.target.value)}
                    placeholder="Auto"
                    className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-[#ECEEF2] placeholder:text-[#565E6E] focus:outline-none focus:border-[#4F6DF5]"
                  />
                </div>
              </div>
            )}

            <div>
              <label
                htmlFor="sidebar-endpoint-input"
                className="block text-xs font-medium text-[#8F98A8] mb-2"
              >
                {backendId === 'auto' ? 'Optional Local GPU Endpoint' : 'Endpoint URL'}
              </label>
              <input
                id="sidebar-endpoint-input"
                type="url"
                value={customEndpointUrl}
                onChange={(e) => onCustomEndpointUrlChange(e.target.value)}
                placeholder="http://192.168.1.50:8000/api/generate"
                className="w-full bg-[#0C0E12] border border-[#252A35] rounded-lg px-3 py-2 text-xs font-mono text-[#ECEEF2] placeholder:text-[#565E6E] focus:outline-none focus:border-[#4F6DF5]"
              />
              <p className="mt-1.5 text-[11px] text-[#6E7787] leading-relaxed">
                {backendId === 'auto'
                  ? 'Tries your GPU endpoint (if reachable), then Airforce, then Pollinations.'
                  : 'On mobile or HTTPS preview, localhost is unreachable — use an HTTPS tunnel URL or export HTML to run on your local LAN.'}
              </p>
            </div>
          </>
        )}
      </div>

      {/* Primary Generate Action Dock */}
      <div className="p-5 border-t border-[#252A35] bg-[#14171E]">
        <button
          type="button"
          onClick={onGenerate}
          disabled={isGenerating || !prompt.trim()}
          className="w-full py-3 px-4 rounded-lg text-sm font-semibold text-white bg-[#4F6DF5] hover:bg-[#415EE6] disabled:opacity-45 disabled:cursor-not-allowed transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
        >
          {isGenerating ? progressText : 'Generate'}
        </button>
        <p className="mt-2.5 text-xs text-[#6E7787] text-center">
          Press Ctrl + Enter to generate · Click any result to inspect
        </p>
      </div>
    </aside>
  );
}
