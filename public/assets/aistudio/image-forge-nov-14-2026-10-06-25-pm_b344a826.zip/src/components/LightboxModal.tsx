import { Check, ChevronLeft, ChevronRight, Copy, Download, RotateCcw, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { GeneratedCard } from '../types/forge';

interface LightboxModalProps {
  card: GeneratedCard | null;
  hasPrev: boolean;
  hasNext: boolean;
  onPrev: () => void;
  onNext: () => void;
  onClose: () => void;
  onDownload: (card: GeneratedCard) => void;
  onReuse: (card: GeneratedCard) => void;
}

export function LightboxModal({
  card,
  hasPrev,
  hasNext,
  onPrev,
  onNext,
  onClose,
  onDownload,
  onReuse,
}: LightboxModalProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!card) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft' && hasPrev) onPrev();
      if (e.key === 'ArrowRight' && hasNext) onNext();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [card, hasPrev, hasNext, onClose, onPrev, onNext]);

  if (!card || !card.url) return null;

  const handleCopySeed = () => {
    navigator.clipboard?.writeText(String(card.seed));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Image inspection"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 md:p-8"
      onClick={onClose}
    >
      <div
        className="w-full max-w-5xl max-h-[90vh] bg-[#14171E] border border-[#252A35] rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-[1fr_320px]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Image canvas */}
        <div className="relative bg-[#0C0E12] flex items-center justify-center min-h-[300px] max-h-[65vh] lg:max-h-[90vh] p-4">
          <img
            src={card.url}
            alt={card.basePrompt}
            referrerPolicy="no-referrer"
            className="max-w-full max-h-full object-contain rounded"
          />

          {hasPrev && (
            <button
              type="button"
              onClick={onPrev}
              aria-label="Previous image"
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-[#14171E]/90 border border-[#252A35] text-[#ECEEF2] hover:border-[#4F6DF5] transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          {hasNext && (
            <button
              type="button"
              onClick={onNext}
              aria-label="Next image"
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-[#14171E]/90 border border-[#252A35] text-[#ECEEF2] hover:border-[#4F6DF5] transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Details panel */}
        <div className="border-t lg:border-t-0 lg:border-l border-[#252A35] p-5 flex flex-col justify-between gap-6 overflow-y-auto">
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-semibold text-[#ECEEF2]">
                Render Details
              </h3>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close inspection dialog"
                className="p-1.5 rounded-lg text-[#8F98A8] hover:text-[#ECEEF2] hover:bg-[#1B1F29] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <span className="block text-xs font-medium text-[#8F98A8] mb-1.5">
                Full Prompt
              </span>
              <p className="text-xs text-[#ECEEF2] leading-relaxed bg-[#0C0E12] border border-[#252A35] rounded-lg p-3">
                {card.fullPrompt}
              </p>
            </div>

            {card.negativePrompt && (
              <div>
                <span className="block text-xs font-medium text-[#8F98A8] mb-1.5">
                  Negative Prompt
                </span>
                <p className="text-xs text-[#CBD5E1] leading-relaxed bg-[#0C0E12] border border-[#252A35] rounded-lg p-3">
                  {card.negativePrompt}
                </p>
              </div>
            )}

            <dl className="grid grid-cols-2 gap-y-3 gap-x-4 text-xs border-t border-[#252A35] pt-4">
              <div>
                <dt className="text-[#6E7787]">Dimensions</dt>
                <dd className="mt-0.5 font-mono tabular-nums text-[#ECEEF2]">
                  {card.width} × {card.height}
                </dd>
              </div>
              <div>
                <dt className="text-[#6E7787]">Seed</dt>
                <dd className="mt-0.5 font-mono tabular-nums text-[#ECEEF2]">{card.seed}</dd>
              </div>
              <div>
                <dt className="text-[#6E7787]">Provider</dt>
                <dd className="mt-0.5 font-mono text-[#ECEEF2]">
                  {card.provider ?? card.backend}
                </dd>
              </div>
              <div>
                <dt className="text-[#6E7787]">Model</dt>
                <dd className="mt-0.5 font-mono text-[#ECEEF2]">{card.model}</dd>
              </div>
              {typeof card.durationMs === 'number' && (
                <div>
                  <dt className="text-[#6E7787]">Latency</dt>
                  <dd className="mt-0.5 font-mono tabular-nums text-[#ECEEF2]">
                    {(card.durationMs / 1000).toFixed(2)}s
                  </dd>
                </div>
              )}
              {typeof card.steps === 'number' && (
                <div>
                  <dt className="text-[#6E7787]">Steps</dt>
                  <dd className="mt-0.5 font-mono tabular-nums text-[#ECEEF2]">{card.steps}</dd>
                </div>
              )}
              {typeof card.guidance === 'number' && (
                <div>
                  <dt className="text-[#6E7787]">Guidance</dt>
                  <dd className="mt-0.5 font-mono tabular-nums text-[#ECEEF2]">{card.guidance}</dd>
                </div>
              )}
              {card.appliedStyles.length > 0 && (
                <div>
                  <dt className="text-[#6E7787]">Styles</dt>
                  <dd className="mt-0.5 text-[#ECEEF2]">{card.appliedStyles.join(', ')}</dd>
                </div>
              )}
            </dl>
          </div>

          <div className="space-y-2 pt-4 border-t border-[#252A35]">
            <button
              type="button"
              onClick={() => onDownload(card)}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-[#4F6DF5] hover:bg-[#415EE6] rounded-lg transition-colors"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              Download PNG
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleCopySeed}
                className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium text-[#ECEEF2] bg-[#0C0E12] border border-[#252A35] rounded-lg hover:border-[#3A4254] transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#16A34A]" aria-hidden="true" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                    Copy Seed
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  onReuse(card);
                  onClose();
                }}
                className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium text-[#ECEEF2] bg-[#0C0E12] border border-[#252A35] rounded-lg hover:border-[#3A4254] transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                Reuse
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
