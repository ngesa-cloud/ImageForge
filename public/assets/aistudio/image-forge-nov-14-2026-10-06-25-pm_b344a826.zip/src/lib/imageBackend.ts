import type {
  BackendConfig,
  CustomHealthResult,
  GenerateResult,
  GenerationParams,
} from '../types/forge';
import { renderLocalMockImage } from './localMockRenderer';
import { STYLE_PRESETS } from './presets';

async function tryAirforce(
  params: GenerationParams,
  authHeader: string
): Promise<{ url: string; seed: number; provider: string }> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (authHeader.trim()) {
    headers['Authorization'] = authHeader.trim();
  }
  const size = `${params.width}x${params.height}`;
  const res = await fetch('https://api.airforce/v1/images/generations', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      prompt: params.prompt,
      model: params.model || 'flux',
      size,
      n: 1,
    }),
  });
  if (!res.ok) {
    let detail = '';
    try {
      const errJson = (await res.json()) as { error?: { message?: string } };
      detail = errJson.error?.message || '';
    } catch {
      // ignore
    }
    throw new Error(`airforce ${res.status}${detail ? ` (${detail})` : ''}`);
  }
  const data = (await res.json()) as { data?: Array<{ url?: string; b64_json?: string }> };
  const first = data.data?.[0];
  const url = first?.url || (first?.b64_json ? `data:image/png;base64,${first.b64_json}` : '');
  if (!url) throw new Error('airforce: no image url in response');
  return { url, seed: params.seed, provider: 'airforce' };
}

async function tryPollinations(
  params: GenerationParams,
  useServerProxy: boolean
): Promise<{ url: string; seed: number; width?: number; height?: number; provider: string }> {
  if (useServerProxy) {
    const response = await fetch('/api/generate/pollinations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: params.prompt,
        negative: params.negativePrompt,
        width: params.width,
        height: params.height,
        seed: params.seed,
        model: params.model,
      }),
    });
    const data = (await response.json().catch(() => ({}))) as {
      url?: string;
      seed?: number;
      width?: number;
      height?: number;
      error?: string;
    };
    if (!response.ok || !data.url) {
      throw new Error(data.error || `pollinations ${response.status}`);
    }
    return {
      url: data.url,
      seed: data.seed ?? params.seed,
      width: data.width ?? params.width,
      height: data.height ?? params.height,
      provider: 'pollinations',
    };
  }

  const full = params.negativePrompt
    ? `${params.prompt} | avoid: ${params.negativePrompt}`
    : params.prompt;
  const url = new URL(`https://image.pollinations.ai/prompt/${encodeURIComponent(full)}`);
  url.searchParams.set('width', String(params.width));
  url.searchParams.set('height', String(params.height));
  url.searchParams.set('seed', String(params.seed));
  url.searchParams.set('model', params.model || 'flux');
  url.searchParams.set('nologo', 'true');
  url.searchParams.set('enhance', 'false');

  const res = await fetch(url.toString());
  if (!res.ok) {
    let detail = '';
    try {
      const text = await res.text();
      const parsed = JSON.parse(text) as { error?: { message?: string } | string };
      if (typeof parsed.error === 'string') detail = parsed.error;
      else if (parsed.error?.message) detail = parsed.error.message;
    } catch {
      // ignore
    }
    throw new Error(`pollinations ${res.status}${detail ? `: ${detail}` : ''}`);
  }
  const blob = await res.blob();
  return {
    url: URL.createObjectURL(blob),
    seed: params.seed,
    width: params.width,
    height: params.height,
    provider: 'pollinations',
  };
}

async function tryCustomEndpoint(
  params: GenerationParams,
  config: BackendConfig
): Promise<{ url: string; seed: number; width?: number; height?: number; provider: string }> {
  const endpointUrl = config.customEndpointUrl.trim();
  if (!endpointUrl) {
    throw new Error('custom endpoint URL is empty');
  }

  const requestBody: Record<string, unknown> = {
    prompt: params.prompt,
    negative: params.negativePrompt,
    width: params.width,
    height: params.height,
    seed: params.seed,
    model: params.model,
  };
  if (typeof params.steps === 'number' && Number.isFinite(params.steps)) {
    requestBody.steps = params.steps;
  }
  if (typeof params.guidance === 'number' && Number.isFinite(params.guidance)) {
    requestBody.guidance = params.guidance;
  }

  if (config.useServerProxy) {
    const response = await fetch('/api/generate/custom', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        endpoint: endpointUrl,
        authHeader: config.customAuthHeader,
        ...requestBody,
      }),
    });
    const data = (await response.json().catch(() => ({}))) as {
      url?: string;
      seed?: number;
      width?: number;
      height?: number;
      error?: string;
    };
    if (!response.ok || !data.url) {
      throw new Error(data.error || `local ${response.status}`);
    }
    return {
      url: data.url,
      seed: data.seed ?? params.seed,
      width: data.width ?? params.width,
      height: data.height ?? params.height,
      provider: 'local-gpu',
    };
  }

  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (config.customAuthHeader.trim()) {
    headers['Authorization'] = config.customAuthHeader.trim();
  }

  let res: Response;
  try {
    res = await fetch(endpointUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify(requestBody),
    });
  } catch (err) {
    const isHttpsPage =
      typeof window !== 'undefined' && window.location.protocol === 'https:';
    const isHttpTarget = endpointUrl.startsWith('http://');
    const isLocalhost =
      endpointUrl.includes('localhost') || endpointUrl.includes('127.0.0.1');

    if (isHttpsPage && isHttpTarget && !isLocalhost) {
      throw new Error(
        `mixed-content blocked (${endpointUrl} over HTTPS)`
      );
    }
    if (isLocalhost) {
      throw new Error(
        `localhost:8000 unreachable from this device`
      );
    }
    throw new Error(
      `network error (${err instanceof Error ? err.message : 'Failed to fetch'})`
    );
  }

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(
      `local ${res.status}${detail ? ` — ${detail.slice(0, 120)}` : ''}`
    );
  }
  const data = (await res.json()) as {
    url?: string;
    seed?: number;
    width?: number;
    height?: number;
  };
  if (!data.url) {
    throw new Error('local backend JSON missing "url"');
  }
  return {
    url: data.url,
    seed: data.seed ?? params.seed,
    width: data.width ?? params.width,
    height: data.height ?? params.height,
    provider: 'local-gpu',
  };
}

/**
 * Unified backend adapter.
 * Passes prompts through untouched with zero client-side filtering.
 */
export async function generate(
  params: GenerationParams,
  config: BackendConfig
): Promise<GenerateResult> {
  const startedAt = performance.now();

  if (config.id === 'local-mock') {
    const res = await renderLocalMockImage({
      prompt: params.prompt,
      width: params.width,
      height: params.height,
      seed: params.seed,
      model: params.model,
    });
    return {
      url: res.url,
      seed: res.seed,
      width: params.width,
      height: params.height,
      durationMs: Math.round(performance.now() - startedAt),
      backend: 'local-mock',
      provider: 'local-mock',
    };
  }

  if (config.id === 'auto') {
    const errs: string[] = [];

    // 1. Try configured Local GPU / Custom HTTP first when reachable
    const endpoint = config.customEndpointUrl.trim();
    const isBrowser = typeof window !== 'undefined';
    const isRemoteHost =
      isBrowser &&
      window.location.hostname !== 'localhost' &&
      window.location.hostname !== '127.0.0.1';
    const isDefaultLocalhost =
      endpoint.includes('localhost') || endpoint.includes('127.0.0.1');

    if (endpoint && (!isRemoteHost || !isDefaultLocalhost)) {
      try {
        const res = await tryCustomEndpoint(params, config);
        return {
          ...res,
          durationMs: Math.round(performance.now() - startedAt),
          backend: 'auto',
        };
      } catch (err) {
        errs.push(err instanceof Error ? err.message : 'local failed');
      }
    } else if (endpoint && isRemoteHost && isDefaultLocalhost) {
      errs.push('local-gpu skipped (localhost unavailable on remote/mobile)');
    }

    // 2. Try Airforce (/v1/images/generations)
    try {
      const res = await tryAirforce(params, config.customAuthHeader);
      return {
        ...res,
        width: params.width,
        height: params.height,
        durationMs: Math.round(performance.now() - startedAt),
        backend: 'auto',
      };
    } catch (err) {
      errs.push(err instanceof Error ? err.message : 'airforce failed');
    }

    // 3. Try Pollinations direct (client IP) then proxy fallback
    try {
      const res = await tryPollinations(params, false);
      return {
        ...res,
        durationMs: Math.round(performance.now() - startedAt),
        backend: 'auto',
      };
    } catch (directErr) {
      const directMsg = directErr instanceof Error ? directErr.message : 'pollinations direct failed';
      try {
        const res = await tryPollinations(params, true);
        return {
          ...res,
          durationMs: Math.round(performance.now() - startedAt),
          backend: 'auto',
        };
      } catch (proxyErr) {
        const proxyMsg = proxyErr instanceof Error ? proxyErr.message : 'pollinations proxy failed';
        errs.push(directMsg === proxyMsg ? directMsg : `${directMsg} / ${proxyMsg}`);
      }
    }

    throw new Error(`All backends failed: ${errs.join(' · ')}`);
  }

  if (config.id === 'pollinations') {
    const res = await tryPollinations(params, config.useServerProxy);
    return {
      ...res,
      durationMs: Math.round(performance.now() - startedAt),
      backend: 'pollinations',
    };
  }

  if (config.id === 'custom-http') {
    const res = await tryCustomEndpoint(params, config);
    return {
      ...res,
      durationMs: Math.round(performance.now() - startedAt),
      backend: 'custom-http',
    };
  }

  throw new Error('Unsupported backend selected.');
}

export async function checkCustomBackendHealth(
  config: BackendConfig
): Promise<CustomHealthResult> {
  const endpointUrl = config.customEndpointUrl.trim();
  if (!endpointUrl) {
    return { ok: false, error: 'Custom endpoint URL is empty.' };
  }

  if (config.useServerProxy) {
    const res = await fetch('/api/health/custom', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        endpointUrl,
        authHeader: config.customAuthHeader,
      }),
    });
    const data = (await res.json().catch(() => ({}))) as CustomHealthResult;
    return data;
  }

  try {
    const parsed = new URL(endpointUrl);
    const headers: Record<string, string> = {};
    if (config.customAuthHeader.trim()) {
      headers['Authorization'] = config.customAuthHeader.trim();
    }
    const res = await fetch(`${parsed.origin}/api/health`, { headers });
    if (!res.ok) {
      return { ok: false, error: `Health check returned HTTP ${res.status}` };
    }
    return (await res.json()) as CustomHealthResult;
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : 'Unable to reach endpoint.',
    };
  }
}

export async function downloadImageAsset(url: string, filename: string): Promise<void> {
  if (url.startsWith('blob:') || url.startsWith('data:')) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return;
  }

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to fetch image (${res.status})`);
  }
  const blob = await res.blob();
  const objectUrl = URL.createObjectURL(blob);
  try {
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } finally {
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
  }
}

export const ADAPTER_CONTRACT_SNIPPET = `// Drop-in backend swap point: replace generate() to point at any image API.
// Passes prompts through untouched with no client-side filter.
// Contract: ({ prompt, negative, width, height, seed, model, steps, guidance }) => Promise<{ url, seed, width, height }>

export async function generate({ prompt, negative, width, height, seed, model, steps, guidance }) {
  const s = seed ?? Math.floor(Math.random() * 1e9);

  // 1. Local unfiltered FastAPI + diffusers GPU backend:
  const res = await fetch("http://localhost:8000/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt, negative, width, height, seed: s, model, steps, guidance }),
  });
  if (!res.ok) throw new Error(\`local backend \${res.status}\`);
  return await res.json(); // -> { url: "data:image/png;base64,...", seed, width, height }

  // 2. Or Pollinations (keyless, CORS-open):
  // const full = negative ? \`\${prompt} | avoid: \${negative}\` : prompt;
  // const url = new URL(\`https://image.pollinations.ai/prompt/\${encodeURIComponent(full)}\`);
  // url.searchParams.set("width", width);
  // url.searchParams.set("height", height);
  // url.searchParams.set("seed", s);
  // url.searchParams.set("model", model || "flux");
  // url.searchParams.set("nologo", "true");
  // const res = await fetch(url.toString());
  // if (!res.ok) throw new Error(\`backend \${res.status}\`);
  // return { url: URL.createObjectURL(await res.blob()), seed: s };
}`;

export const FASTAPI_DIFFUSERS_SHIM = `# language: Python 3.10+, file: backend/server.py, target: CUDA / MPS / CPU
# pip install fastapi uvicorn pillow diffusers transformers accelerate safetensors torch
# Requirements: an SD/SDXL/Flux checkpoint in local disk or HF hub id.
# No content filter is applied in this server. The safety_checker is explicitly disabled below.

import base64
import io
import os
import random
from typing import Optional

import torch
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from diffusers import (
    AutoPipelineForText2Image,
    StableDiffusionPipeline,
    StableDiffusionXLPipeline,
    FluxPipeline,
)

# ---------------- config ----------------
MODEL_ID = os.environ.get("MODEL_ID", "stabilityai/sd-turbo")  # swap to any SD/SDXL/Flux id or local path
DEVICE = os.environ.get("DEVICE", "cuda" if torch.cuda.is_available() else "cpu")
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32
LORA_PATH = os.environ.get("LORA_PATH", "").strip()
LORA_WEIGHT = float(os.environ.get("LORA_WEIGHT", "1.0"))
# ----------------------------------------

app = FastAPI(title="image-forge backend")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

pipe = None


def load_pipeline():
    """Load lazily, once. Chooses pipeline class by model id; forces safety_checker off."""
    global pipe
    if pipe is not None:
        return pipe

    kwargs = dict(torch_dtype=DTYPE)
    lower_id = MODEL_ID.lower()

    if lower_id.endswith(".safetensors"):
        if "xl" in lower_id:
            pipe = StableDiffusionXLPipeline.from_single_file(MODEL_ID, **kwargs)
        elif "flux" in lower_id:
            pipe = FluxPipeline.from_single_file(MODEL_ID, **kwargs)
        else:
            pipe = StableDiffusionPipeline.from_single_file(
                MODEL_ID,
                safety_checker=None,
                requires_safety_checker=False,
                **kwargs,
            )
    # SD 1.x/2.x: disable safety_checker at load
    elif "stable-diffusion" in lower_id and "xl" not in lower_id and "flux" not in lower_id:
        pipe = StableDiffusionPipeline.from_pretrained(
            MODEL_ID,
            safety_checker=None,
            requires_safety_checker=False,
            **kwargs,
        )
    elif "xl" in lower_id:
        pipe = StableDiffusionXLPipeline.from_pretrained(MODEL_ID, **kwargs)
    elif "flux" in lower_id:
        pipe = FluxPipeline.from_pretrained(MODEL_ID, **kwargs)
    else:
        pipe = AutoPipelineForText2Image.from_pretrained(MODEL_ID, **kwargs)

    # strip any residual checker references
    if hasattr(pipe, "safety_checker"):
        pipe.safety_checker = None
    if hasattr(pipe, "feature_extractor"):
        pipe.feature_extractor = None

    pipe = pipe.to(DEVICE)

    if LORA_PATH:
        try:
            pipe.load_lora_weights(LORA_PATH, adapter_name="steer")
            pipe.set_adapters(["steer"], adapter_weights=[LORA_WEIGHT])
        except Exception as e:
            print(f"[lora] load failed: {e}")

    if DEVICE == "cuda":
        try:
            pipe.enable_model_cpu_offload()
        except Exception:
            pipe.to("cuda")
        try:
            pipe.enable_vae_slicing()
        except Exception:
            pass

    return pipe


class GenRequest(BaseModel):
    prompt: str
    negative: str = ""
    width: int = 768
    height: int = 768
    seed: Optional[int] = None
    model: Optional[str] = None
    steps: Optional[int] = None
    guidance: Optional[float] = None


@app.get("/api/health")
def health():
    return {"ok": True, "model": MODEL_ID, "device": DEVICE, "lora": LORA_PATH or None, "loaded": pipe is not None}


@app.post("/api/generate")
def generate(req: GenRequest):
    if not req.prompt or not req.prompt.strip():
        raise HTTPException(status_code=400, detail="empty prompt")

    w = max(256, min(1536, (req.width // 8) * 8))
    h = max(256, min(1536, (req.height // 8) * 8))

    seed = req.seed if req.seed is not None else random.randint(0, 2**32 - 1)
    generator = torch.Generator(device=DEVICE).manual_seed(seed)

    p = load_pipeline()
    lower_id = MODEL_ID.lower()
    is_flux = "flux" in lower_id
    is_turbo = "turbo" in lower_id

    steps = req.steps or (4 if is_turbo else 28 if is_flux else 30)
    guidance = req.guidance if req.guidance is not None else (0.0 if is_turbo else 3.5 if is_flux else 7.0)

    call_kwargs = dict(
        prompt=req.prompt,
        width=w,
        height=h,
        num_inference_steps=steps,
        generator=generator,
        guidance_scale=guidance,
    )
    if not is_flux:
        call_kwargs["negative_prompt"] = req.negative or None

    with torch.inference_mode():
        result = p(**call_kwargs)

    img = result.images[0]
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()

    return {"url": f"data:image/png;base64,{b64}", "seed": seed, "width": w, "height": h}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)`;

export const DOCKER_COMPOSE_SNIPPET = `# file: docker-compose.yml — boots GPU backend, Express proxy, and nginx frontend together
services:
  backend:
    build: ./backend
    container_name: forge-backend
    ports:
      - "8000:8000"
    volumes:
      - hf-models:/models/hf
    environment:
      - MODEL_ID=\${MODEL_ID:-stabilityai/sd-turbo}
      - DEVICE=cuda
      - LORA_PATH=\${LORA_PATH:-}
      - LORA_WEIGHT=\${LORA_WEIGHT:-1.0}
      - HF_HUB_ENABLE_HF_TRANSFER=1
      - HF_TOKEN=\${HF_TOKEN:-}
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    restart: unless-stopped

  proxy:
    build:
      context: .
      dockerfile: proxy/Dockerfile
    container_name: forge-proxy
    ports:
      - "3000:3000"
    environment:
      - CUSTOM_ENDPOINT=http://backend:8000/api/generate
      - CUSTOM_HEALTH=http://backend:8000/api/health
    depends_on:
      backend:
        condition: service_healthy
    restart: unless-stopped

  web:
    image: nginx:1.27-alpine
    container_name: forge-web
    ports:
      - "8080:80"
    volumes:
      - ./web:/usr/share/nginx/html:ro
      - ./nginx.conf:/etc/nginx/conf.d/default.conf:ro
    depends_on:
      - proxy
    restart: unless-stopped

volumes:
  hf-models:`;

export function buildSingleFileHtml(config: BackendConfig): string {
  const stylesJson = JSON.stringify(
    STYLE_PRESETS.map((s) => ({ name: s.name, suffix: s.suffix }))
  );
  const customEndpoint = JSON.stringify(
    config.customEndpointUrl || 'http://localhost:8000/api/generate'
  );

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Image Forge — Text to Image</title>
<style>
  :root{
    --bg:#0c0e12; --panel:#14171e; --panel-2:#1b1f29; --line:#252a35;
    --txt:#eceef2; --dim:#8f98a8; --accent:#4f6df5; --danger:#dc2626; --radius:12px;
  }
  *{box-sizing:border-box}
  html,body{margin:0;height:100%}
  body{background:var(--bg);color:var(--txt);font:14px/1.5 system-ui,-apple-system,sans-serif;display:flex;flex-direction:column}
  header{padding:14px 24px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line)}
  header h1{font-size:16px;font-weight:650;margin:0}
  main{display:grid;grid-template-columns:360px 1fr;flex:1;min-height:0}
  @media(max-width:880px){main{grid-template-columns:1fr}}
  .controls{background:var(--panel);border-right:1px solid var(--line);padding:20px;overflow:auto}
  label{display:block;font-size:12px;font-weight:500;color:var(--dim);margin:14px 0 6px}
  label:first-child{margin-top:0}
  textarea,input,select{width:100%;background:var(--panel-2);border:1px solid var(--line);color:var(--txt);border-radius:8px;padding:9px 11px;font:inherit;outline:none}
  textarea{min-height:90px;resize:vertical}
  textarea:focus,input:focus,select:focus{border-color:var(--accent)}
  .row{display:flex;gap:10px}.row>*{flex:1}
  .styles{display:flex;flex-wrap:wrap;gap:6px}
  .chip{font-size:12px;padding:6px 10px;border-radius:8px;border:1px solid var(--line);background:var(--panel-2);color:var(--dim);cursor:pointer}
  .chip[aria-pressed=true]{background:var(--accent);border-color:var(--accent);color:#fff}
  .generate{margin-top:20px;width:100%;padding:11px;border:none;border-radius:8px;cursor:pointer;font:inherit;font-weight:600;color:#fff;background:var(--accent)}
  .generate:disabled{opacity:.5;cursor:not-allowed}
  .stage{padding:24px;overflow:auto}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden}
  .thumb{aspect-ratio:1;background:var(--panel-2);position:relative;display:flex;align-items:center;justify-content:center}
  .thumb img{width:100%;height:100%;object-fit:cover;display:block}
  .err{color:#fca5a5;font-size:12px;padding:14px;text-align:center;line-height:1.4}
  .meta{padding:10px 12px;border-top:1px solid var(--line);display:flex;align-items:center;gap:8px;font-size:12px;color:var(--dim)}
  .meta span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .meta a{font-size:12px;background:var(--panel-2);border:1px solid var(--line);color:var(--txt);border-radius:6px;padding:4px 8px;cursor:pointer;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>Image Forge</h1>
  <span style="font-size:12px;color:var(--dim)">Backend: local</span>
</header>
<main>
  <section class="controls">
    <label for="prompt">Prompt</label>
    <textarea id="prompt" placeholder="a lighthouse at dusk, cold blue mist, cinematic, 35mm film grain"></textarea>
    <label for="neg">Negative Prompt</label>
    <textarea id="neg" placeholder="blurry, watermark, text" style="min-height:60px"></textarea>
    <label>Style Presets</label>
    <div class="styles" id="styles"></div>
    <div class="row">
      <div><label for="width">Width</label><input id="width" type="number" value="768" min="256" max="1536" step="64"></div>
      <div><label for="height">Height</label><input id="height" type="number" value="768" min="256" max="1536" step="64"></div>
    </div>
    <div class="row">
      <div><label for="count">Batch</label><select id="count"><option>1</option><option selected>2</option><option>4</option><option>6</option></select></div>
      <div><label for="seed">Seed</label><input id="seed" type="number" placeholder="random" min="0"></div>
    </div>
    <div class="row">
      <div><label for="steps">Steps</label><input id="steps" type="number" placeholder="auto" min="1" max="150"></div>
      <div><label for="guidance">Guidance</label><input id="guidance" type="number" placeholder="auto" min="0" max="30" step="0.5"></div>
    </div>
    <label for="model">Model</label>
    <select id="model"><option value="sd-turbo">sd-turbo</option><option value="sdxl-base-1.0">sdxl-base-1.0</option><option value="flux">flux</option></select>
    <label for="localUrl">Local Endpoint (use PC LAN IP on mobile)</label>
    <input id="localUrl" type="url" value="" placeholder="http://192.168.1.50:8000/api/generate">
    <button class="generate" id="go">Generate</button>
    <p id="status" style="font-size:12px;color:var(--dim);margin:10px 0 0">Idle</p>
  </section>
  <section class="stage"><div class="grid" id="grid"></div></section>
</main>
<script>
const DEFAULT_ENDPOINT = ${customEndpoint};
const STYLES = ${stylesJson};
const selected = new Set();
const $ = (id) => document.getElementById(id);

$("localUrl").value = localStorage.getItem("forge_local_url") || DEFAULT_ENDPOINT;
$("localUrl").addEventListener("input", () => {
  localStorage.setItem("forge_local_url", $("localUrl").value.trim());
});

STYLES.forEach((s) => {
  const b = document.createElement("button");
  b.type = "button"; b.className = "chip"; b.textContent = s.name;
  b.setAttribute("aria-pressed", "false");
  b.onclick = () => {
    const on = b.getAttribute("aria-pressed") === "true";
    b.setAttribute("aria-pressed", String(!on));
    on ? selected.delete(s.suffix) : selected.add(s.suffix);
  };
  $("styles").appendChild(b);
});

async function generate({ prompt, negative, width, height, seed, model, steps, guidance }) {
  const endpoint = $("localUrl").value.trim();
  const s = seed ?? Math.floor(Math.random() * 1e9);
  const body = { prompt, negative, width, height, seed: s, model };
  if (steps !== undefined) body.steps = steps;
  if (guidance !== undefined) body.guidance = guidance;
  let res;
  try {
    res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
  } catch (e) {
    throw new Error("Network error reaching " + endpoint + ". Is server.py running? On mobile, use your PC's LAN IP (e.g. 192.168.x.x).");
  }
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error("Server " + res.status + (detail ? " — " + detail.slice(0, 120) : ""));
  }
  return await res.json();
}

async function go() {
  const base = $("prompt").value.trim();
  if (!base) return $("prompt").focus();
  const prompt = base + [...selected].join("");
  const negative = $("neg").value.trim();
  const width = +$("width").value || 768;
  const height = +$("height").value || 768;
  const batch = +$("count").value || 1;
  const seedInput = $("seed").value.trim();
  const stepsVal = $("steps").value.trim();
  const guidanceVal = $("guidance").value.trim();
  const steps = stepsVal !== "" ? +stepsVal : undefined;
  const guidance = guidanceVal !== "" ? +guidanceVal : undefined;
  const model = $("model").value;
  $("go").disabled = true;
  $("status").textContent = "Generating " + batch + "...";

  const cards = Array.from({ length: batch }, () => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = '<div class="thumb">Rendering...</div><div class="meta"><span></span><a hidden>Download</a></div>';
    $("grid").prepend(card);
    return card;
  });

  await Promise.allSettled(cards.map(async (card, i) => {
    const seed = seedInput !== "" ? +seedInput + i : Math.floor(Math.random() * 1e9);
    try {
      const res = await generate({ prompt, negative, width, height, seed, model, steps, guidance });
      card.querySelector(".thumb").innerHTML = "";
      const img = document.createElement("img");
      img.src = res.url; img.alt = base;
      card.querySelector(".thumb").appendChild(img);
      card.querySelector(".meta span").textContent = "seed " + res.seed;
      const a = card.querySelector("a");
      a.href = res.url; a.download = "forge-" + res.seed + ".png"; a.hidden = false;
    } catch (e) {
      card.querySelector(".thumb").innerHTML = '<div class="err">Generation Failed<br>' + e.message + '</div>';
    }
  }));

  $("go").disabled = false;
  $("status").textContent = "Done";
}

$("go").onclick = go;
$("prompt").addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); go(); }
});
</script>
</body>
</html>`;
}
