// Deterministic, zero-key procedural canvas renderer for the "local-mock" backend.
// Produces reproducible PNG artwork seeded by (prompt + seed + model + dimensions)
// so the entire UI workflow, batch seeding, and downloads can be verified offline.

function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function createRng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface Palette {
  skyTop: string;
  skyMid: string;
  horizon: string;
  glow: string;
  silhouetteNear: string;
  silhouetteFar: string;
  accent: string;
}

function pickPalette(prompt: string, rng: () => number): Palette {
  const p = prompt.toLowerCase();
  if (p.includes('dusk') || p.includes('lighthouse') || p.includes('mist') || p.includes('ocean') || p.includes('blue')) {
    return {
      skyTop: '#0b1628',
      skyMid: '#1b3554',
      horizon: '#3c6282',
      glow: '#f4b860',
      silhouetteFar: '#16273c',
      silhouetteNear: '#09111b',
      accent: '#7aa7c7',
    };
  }
  if (p.includes('cyberpunk') || p.includes('neon') || p.includes('rain') || p.includes('night')) {
    return {
      skyTop: '#080a16',
      skyMid: '#151b38',
      horizon: '#282d57',
      glow: '#4fd1c5',
      silhouetteFar: '#14172b',
      silhouetteNear: '#070811',
      accent: '#5b7cfa',
    };
  }
  if (p.includes('sunset') || p.includes('desert') || p.includes('amber') || p.includes('gold') || p.includes('oil')) {
    return {
      skyTop: '#1d131a',
      skyMid: '#5b2a29',
      horizon: '#c96f3b',
      glow: '#ffd285',
      silhouetteFar: '#3d1e20',
      silhouetteNear: '#190c0e',
      accent: '#e69f56',
    };
  }
  if (p.includes('forest') || p.includes('fern') || p.includes('green') || p.includes('watercolor')) {
    return {
      skyTop: '#0d1b18',
      skyMid: '#1e3a34',
      horizon: '#4a7365',
      glow: '#d8e2b8',
      silhouetteFar: '#19302a',
      silhouetteNear: '#091411',
      accent: '#8cb399',
    };
  }
  if (p.includes('monochrome') || p.includes('leica') || p.includes('black and white')) {
    return {
      skyTop: '#111215',
      skyMid: '#2a2d33',
      horizon: '#686d78',
      glow: '#e2e5ec',
      silhouetteFar: '#24262b',
      silhouetteNear: '#0c0d10',
      accent: '#aeb4c0',
    };
  }

  const hue = Math.floor(rng() * 360);
  return {
    skyTop: `hsl(${hue}, 30%, 9%)`,
    skyMid: `hsl(${(hue + 14) % 360}, 34%, 20%)`,
    horizon: `hsl(${(hue + 28) % 360}, 38%, 36%)`,
    glow: `hsl(${(hue + 48) % 360}, 75%, 74%)`,
    silhouetteFar: `hsl(${hue}, 28%, 16%)`,
    silhouetteNear: `hsl(${hue}, 26%, 7%)`,
    accent: `hsl(${(hue + 40) % 360}, 58%, 62%)`,
  };
}

export async function renderLocalMockImage(params: {
  prompt: string;
  width: number;
  height: number;
  seed: number;
  model: string;
}): Promise<{ url: string; seed: number }> {
  const { prompt, width, height, seed, model } = params;
  // Brief realistic async yield so pending states are observable
  await new Promise((r) => setTimeout(r, 260 + (seed % 280)));

  const combinedSeed = (seed ^ hashString(`${prompt}:${model}`)) >>> 0;
  const rng = createRng(combinedSeed);
  const palette = pickPalette(prompt, rng);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('2D canvas context unavailable.');
  }

  // 1. Atmospheric sky gradient
  const skyGrad = ctx.createLinearGradient(0, 0, 0, height * 0.78);
  skyGrad.addColorStop(0, palette.skyTop);
  skyGrad.addColorStop(0.58, palette.skyMid);
  skyGrad.addColorStop(1, palette.horizon);
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, height);

  // 2. Celestial / focal light source
  const sunX = width * (0.22 + rng() * 0.56);
  const sunY = height * (0.24 + rng() * 0.28);
  const sunRadius = Math.min(width, height) * (0.12 + rng() * 0.14);

  const glowGrad = ctx.createRadialGradient(sunX, sunY, sunRadius * 0.1, sunX, sunY, sunRadius * 3.4);
  glowGrad.addColorStop(0, palette.glow);
  glowGrad.addColorStop(0.28, `${palette.glow}55`);
  glowGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = glowGrad;
  ctx.fillRect(0, 0, width, height);

  ctx.beginPath();
  ctx.arc(sunX, sunY, sunRadius * 0.45, 0, Math.PI * 2);
  ctx.fillStyle = `${palette.glow}dd`;
  ctx.fill();

  // 3. Geometric or organic focal elements depending on model
  if (model === 'geometric-v1') {
    const shapes = 5 + Math.floor(rng() * 5);
    for (let i = 0; i < shapes; i++) {
      ctx.save();
      ctx.translate(width * (0.15 + rng() * 0.7), height * (0.2 + rng() * 0.55));
      ctx.rotate(rng() * Math.PI);
      const size = Math.min(width, height) * (0.08 + rng() * 0.22);
      ctx.strokeStyle = `${palette.accent}55`;
      ctx.lineWidth = Math.max(1.5, width * 0.003);
      ctx.strokeRect(-size / 2, -size / 2, size, size);
      ctx.restore();
    }
  } else {
    // Subtle stars or atmospheric bokeh particles
    const stars = 36 + Math.floor(rng() * 44);
    for (let i = 0; i < stars; i++) {
      const sx = rng() * width;
      const sy = rng() * height * 0.62;
      const sr = 0.6 + rng() * 1.6;
      ctx.fillStyle = `rgba(255,255,255,${0.12 + rng() * 0.45})`;
      ctx.beginPath();
      ctx.arc(sx, sy, sr, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // 4. Layered horizon ridges
  const layers = 3;
  for (let l = 0; l < layers; l++) {
    const baseY = height * (0.56 + l * 0.12);
    const amp = height * (0.08 - l * 0.015);
    const freq = 0.004 + rng() * 0.006;
    const phase = rng() * Math.PI * 2;

    ctx.beginPath();
    ctx.moveTo(0, height);
    for (let x = 0; x <= width; x += 8) {
      const n =
        Math.sin(x * freq + phase) * amp +
        Math.cos(x * freq * 2.3 + phase * 1.7) * (amp * 0.45);
      ctx.lineTo(x, baseY + n);
    }
    ctx.lineTo(width, height);
    ctx.closePath();

    ctx.fillStyle = l === 0 ? palette.silhouetteFar : l === 1 ? palette.horizon : palette.silhouetteNear;
    ctx.globalAlpha = l === 1 ? 0.55 : 0.92;
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // 5. Optional lighthouse / monolith silhouette if prompt suggests architecture
  const lower = prompt.toLowerCase();
  if (lower.includes('lighthouse') || lower.includes('tower') || lower.includes('observatory') || lower.includes('city')) {
    const tx = width * (0.35 + rng() * 0.3);
    const baseH = height * 0.72;
    const towerW = width * 0.045;
    const towerH = height * 0.24;
    ctx.fillStyle = palette.silhouetteNear;
    ctx.beginPath();
    ctx.moveTo(tx - towerW * 0.7, baseH);
    ctx.lineTo(tx - towerW * 0.35, baseH - towerH);
    ctx.lineTo(tx + towerW * 0.35, baseH - towerH);
    ctx.lineTo(tx + towerW * 0.7, baseH);
    ctx.closePath();
    ctx.fill();

    // Beacon beam
    const beamY = baseH - towerH + 6;
    const beamGrad = ctx.createLinearGradient(tx, beamY, tx + width * 0.42, beamY - height * 0.08);
    beamGrad.addColorStop(0, `${palette.glow}cc`);
    beamGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = beamGrad;
    ctx.beginPath();
    ctx.moveTo(tx, beamY);
    ctx.lineTo(tx + width * 0.45, beamY - height * 0.14);
    ctx.lineTo(tx + width * 0.45, beamY + height * 0.04);
    ctx.closePath();
    ctx.fill();
  }

  // 6. Subtle mist & film grain overlay
  const mistGrad = ctx.createLinearGradient(0, height * 0.62, 0, height);
  mistGrad.addColorStop(0, 'transparent');
  mistGrad.addColorStop(0.5, `${palette.accent}1a`);
  mistGrad.addColorStop(1, `${palette.silhouetteNear}cc`);
  ctx.fillStyle = mistGrad;
  ctx.fillRect(0, height * 0.62, width, height * 0.38);

  // Subtle corner watermark-free framing vignette
  const vignette = ctx.createRadialGradient(
    width / 2,
    height / 2,
    Math.min(width, height) * 0.35,
    width / 2,
    height / 2,
    Math.max(width, height) * 0.75
  );
  vignette.addColorStop(0, 'transparent');
  vignette.addColorStop(1, 'rgba(0,0,0,0.34)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => {
      if (b) resolve(b);
      else reject(new Error('Failed to encode PNG blob.'));
    }, 'image/png');
  });

  return {
    url: URL.createObjectURL(blob),
    seed,
  };
}
