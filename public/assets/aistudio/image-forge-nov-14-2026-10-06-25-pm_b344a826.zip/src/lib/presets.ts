import type { AspectPreset, BackendId, ModelOption, StylePreset } from '../types/forge';

export const STYLE_PRESETS: StylePreset[] = [
  {
    id: 'cinematic',
    name: 'Cinematic',
    suffix: ', cinematic lighting, shallow depth of field, film grain, 35mm',
    description: 'Anamorphic lighting and 35mm film grain',
  },
  {
    id: 'anime',
    name: 'Anime',
    suffix: ', anime key visual, clean lineart, vibrant colors, studio quality',
    description: 'Clean key visual linework and cel color',
  },
  {
    id: 'oil-paint',
    name: 'Oil Paint',
    suffix: ', oil on canvas, thick impasto brushstrokes, museum lighting',
    description: 'Textured impasto brushwork on canvas',
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk',
    suffix: ', cyberpunk, neon reflections, rain-slick streets, high contrast',
    description: 'Rain-slick streets and nocturnal contrast',
  },
  {
    id: 'studio',
    name: 'Studio',
    suffix: ', studio product photography, softbox lighting, neutral backdrop',
    description: 'Diffused softbox commercial framing',
  },
  {
    id: 'watercolor',
    name: 'Watercolor',
    suffix: ', loose watercolor wash, cold-press paper texture, soft edges',
    description: 'Pigment washes on cold-press paper',
  },
  {
    id: '3d-render',
    name: '3D Render',
    suffix: ', octane render, subsurface scattering, volumetric light, 8k',
    description: 'Physically-based volumetric studio shading',
  },
  {
    id: 'monochrome',
    name: 'Monochrome',
    suffix: ', black and white Leica photography, silver gelatin print, high contrast',
    description: 'Silver gelatin monochrome rangefinder look',
  },
];

export const ASPECT_PRESETS: AspectPreset[] = [
  { id: '1:1', label: '1:1', ratio: 'Square', width: 768, height: 768 },
  { id: '4:3', label: '4:3', ratio: 'Standard', width: 896, height: 640 },
  { id: '3:4', label: '3:4', ratio: 'Portrait', width: 640, height: 896 },
  { id: '16:9', label: '16:9', ratio: 'Wide', width: 1024, height: 576 },
  { id: '9:16', label: '9:16', ratio: 'Vertical', width: 576, height: 1024 },
];

export const MODELS_BY_BACKEND: Record<BackendId, ModelOption[]> = {
  auto: [
    { id: 'flux', label: 'flux', note: 'Auto-routed Flux' },
    { id: 'turbo', label: 'turbo', note: 'Auto-routed Turbo' },
    { id: 'sd-turbo', label: 'sd-turbo', note: 'Local SD Turbo fallback' },
  ],
  pollinations: [
    { id: 'flux', label: 'flux', note: 'Balanced detail & prompt adherence' },
    { id: 'turbo', label: 'turbo', note: 'Fastest turnaround' },
    { id: 'kontext', label: 'kontext', note: 'Contextual composition' },
  ],
  'local-mock': [
    { id: 'procedural-v1', label: 'procedural-v1', note: 'Deterministic seeded canvas synth' },
    { id: 'geometric-v1', label: 'geometric-v1', note: 'Architectural vector & light layers' },
  ],
  'custom-http': [
    { id: 'sd-turbo', label: 'sd-turbo', note: 'Fast 4-step local test checkpoint' },
    { id: 'sdxl-base-1.0', label: 'sdxl-base-1.0', note: 'Stable Diffusion XL 1.0' },
    { id: 'flux.1-schnell', label: 'flux.1-schnell', note: 'Flux.1 Schnell local pipeline' },
    { id: 'default', label: 'default', note: 'Server MODEL_ID checkpoint' },
  ],
};

export const STARTER_PROMPTS = [
  {
    title: 'Coastal Lighthouse at Dusk',
    prompt: 'a lonely basalt lighthouse at dusk, cold blue Atlantic mist, warm amber beacon cutting through fog, 35mm film grain',
    negative: 'blurry, watermark, text, oversaturated',
    styles: ['cinematic'],
    width: 1024,
    height: 576,
  },
  {
    title: 'Brutalist Conservatory',
    prompt: 'interior of a concrete brutalist greenhouse filled with giant ferns, afternoon sunbeams casting sharp geometric shadows',
    negative: 'people, clutter, low resolution, distortion',
    styles: ['studio'],
    width: 768,
    height: 768,
  },
  {
    title: 'Alpine Observatory',
    prompt: 'minimalist astronomical observatory dome perched on a snowy granite ridge under a clear starfield, crisp twilight',
    negative: 'clouds, text, watermark, artifacts',
    styles: ['3d-render'],
    width: 896,
    height: 640,
  },
  {
    title: 'Kyoto Rainy Alley',
    prompt: 'quiet wooden alleyway in Kyoto after rain, paper lanterns reflecting on wet slate cobblestones, misty evening atmosphere',
    negative: 'crowds, modern cars, neon signs, blurry',
    styles: ['watercolor'],
    width: 640,
    height: 896,
  },
];

export function clampDimension(value: number): number {
  if (!Number.isFinite(value)) return 768;
  const clamped = Math.max(256, Math.min(1536, value));
  return Math.round(clamped / 64) * 64;
}
