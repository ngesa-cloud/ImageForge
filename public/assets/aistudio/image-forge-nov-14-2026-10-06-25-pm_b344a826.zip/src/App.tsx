import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BackendAdapterView } from './components/BackendAdapterView';
import { ControlsSidebar } from './components/ControlsSidebar';
import { GalleryStage } from './components/GalleryStage';
import { LightboxModal } from './components/LightboxModal';
import { TopBar, type WorkspaceTab } from './components/TopBar';
import { buildSingleFileHtml, downloadImageAsset, generate } from './lib/imageBackend';
import {
  MODELS_BY_BACKEND,
  STARTER_PROMPTS,
  STYLE_PRESETS,
  clampDimension,
} from './lib/presets';
import type { BackendConfig, BackendId, GeneratedCard } from './types/forge';

function makeId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('studio');

  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [selectedStyleIds, setSelectedStyleIds] = useState<string[]>([]);
  const [width, setWidth] = useState(768);
  const [height, setHeight] = useState(768);
  const [batchCount, setBatchCount] = useState(1);
  const [seedInput, setSeedInput] = useState('');
  const [stepsInput, setStepsInput] = useState('');
  const [guidanceInput, setGuidanceInput] = useState('');

  const [backendConfig, setBackendConfig] = useState<BackendConfig>(() => {
    const defaults: BackendConfig = {
      id: 'auto',
      customEndpointUrl: 'http://localhost:8000/api/generate',
      customAuthHeader: '',
      useServerProxy: true,
    };
    try {
      const saved = localStorage.getItem('image_forge_backend_config_v2');
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<BackendConfig>;
        return { ...defaults, ...parsed };
      }
    } catch {
      // Ignore storage errors
    }
    return defaults;
  });
  const [model, setModel] = useState<string>(() => MODELS_BY_BACKEND[backendConfig.id][0]?.id ?? 'flux');

  useEffect(() => {
    try {
      localStorage.setItem('image_forge_backend_config_v2', JSON.stringify(backendConfig));
    } catch {
      // Ignore storage errors
    }
  }, [backendConfig]);

  const [cards, setCards] = useState<GeneratedCard[]>([]);
  const [activeJobs, setActiveJobs] = useState(0);
  const [progressText, setProgressText] = useState('Generate');
  const [lightboxId, setLightboxId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const cardsRef = useRef<GeneratedCard[]>(cards);
  cardsRef.current = cards;

  useEffect(() => {
    return () => {
      cardsRef.current.forEach((c) => {
        if (c.url?.startsWith('blob:')) URL.revokeObjectURL(c.url);
      });
    };
  }, []);

  const showNotice = useCallback((msg: string) => {
    setNotice(msg);
    setTimeout(() => {
      setNotice((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  const handleBackendIdChange = useCallback((nextId: BackendId) => {
    setBackendConfig((prev) => ({
      ...prev,
      id: nextId,
      // Default to direct browser fetch when user picks local GPU box so localhost:8000 works from the user's machine
      useServerProxy: nextId === 'custom-http' ? false : prev.useServerProxy,
    }));
    const available = MODELS_BY_BACKEND[nextId];
    if (available.length > 0) {
      setModel(available[0].id);
    }
  }, []);

  const handleConfigChange = useCallback(
    (next: BackendConfig) => {
      setBackendConfig(next);
      const available = MODELS_BY_BACKEND[next.id];
      if (available.length > 0 && !available.some((m) => m.id === model)) {
        setModel(available[0].id);
      }
    },
    [model]
  );

  const handleToggleStyle = useCallback((id: string) => {
    setSelectedStyleIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }, []);

  const runBatch = useCallback(
    async (opts: {
      basePrompt: string;
      negPrompt: string;
      styleIds: string[];
      w: number;
      h: number;
      batch: number;
      seedStr: string;
      stepsStr: string;
      guidanceStr: string;
      selectedModel: string;
    }) => {
      const trimmedBase = opts.basePrompt.trim();
      if (!trimmedBase) return;

      const matchedStyles = STYLE_PRESETS.filter((s) => opts.styleIds.includes(s.id));
      const fullPrompt = trimmedBase + matchedStyles.map((s) => s.suffix).join('');
      const clampedW = clampDimension(opts.w);
      const clampedH = clampDimension(opts.h);
      const parsedSeed =
        opts.seedStr.trim() !== '' ? Math.abs(Math.floor(Number(opts.seedStr))) : null;
      const parsedSteps =
        opts.stepsStr.trim() !== '' && Number.isFinite(Number(opts.stepsStr))
          ? Math.max(1, Math.min(150, Math.round(Number(opts.stepsStr))))
          : undefined;
      const parsedGuidance =
        opts.guidanceStr.trim() !== '' && Number.isFinite(Number(opts.guidanceStr))
          ? Math.max(0, Math.min(30, Number(opts.guidanceStr)))
          : undefined;

      const batchCards: GeneratedCard[] = Array.from({ length: opts.batch }, (_, i) => {
        const seed =
          parsedSeed !== null && Number.isFinite(parsedSeed)
            ? parsedSeed + i
            : Math.floor(Math.random() * 1_000_000_000);
        return {
          id: makeId(),
          basePrompt: trimmedBase,
          fullPrompt,
          negativePrompt: opts.negPrompt.trim(),
          appliedStyles: matchedStyles.map((s) => s.name),
          width: clampedW,
          height: clampedH,
          seed,
          model: opts.selectedModel,
          steps: parsedSteps,
          guidance: parsedGuidance,
          backend: backendConfig.id,
          status: 'pending',
          createdAt: Date.now() + i,
        };
      });

      setCards((prev) => [...batchCards, ...prev]);
      setActiveJobs((n) => n + 1);

      let completed = 0;
      setProgressText(`Generating 0/${opts.batch}...`);

      await Promise.allSettled(
        batchCards.map(async (card) => {
          try {
            const res = await generate(
              {
                prompt: card.fullPrompt,
                negativePrompt: card.negativePrompt,
                width: card.width,
                height: card.height,
                seed: card.seed,
                model: card.model,
                steps: card.steps,
                guidance: card.guidance,
              },
              backendConfig
            );

            setCards((prev) =>
              prev.map((item) =>
                item.id === card.id
                  ? {
                      ...item,
                      status: 'ready',
                      url: res.url,
                      seed: res.seed,
                      provider: res.provider,
                      width: res.width ?? item.width,
                      height: res.height ?? item.height,
                      durationMs: res.durationMs,
                    }
                  : item
              )
            );
          } catch (err) {
            const errorMsg = err instanceof Error ? err.message : 'Generation failed.';
            setCards((prev) =>
              prev.map((item) =>
                item.id === card.id ? { ...item, status: 'error', error: errorMsg } : item
              )
            );
          } finally {
            completed += 1;
            setProgressText(`Generating ${completed}/${opts.batch}...`);
          }
        })
      );

      setActiveJobs((n) => Math.max(0, n - 1));
    },
    [backendConfig]
  );

  const handleGenerate = useCallback(() => {
    if (activeJobs > 0 || !prompt.trim()) return;
    void runBatch({
      basePrompt: prompt,
      negPrompt: negativePrompt,
      styleIds: selectedStyleIds,
      w: width,
      h: height,
      batch: batchCount,
      seedStr: seedInput,
      stepsStr: stepsInput,
      guidanceStr: guidanceInput,
      selectedModel: model,
    });
  }, [
    activeJobs,
    prompt,
    negativePrompt,
    selectedStyleIds,
    width,
    height,
    batchCount,
    seedInput,
    stepsInput,
    guidanceInput,
    model,
    runBatch,
  ]);

  const handleApplyStarter = useCallback(
    (starter: (typeof STARTER_PROMPTS)[number], autoRun: boolean) => {
      setPrompt(starter.prompt);
      setNegativePrompt(starter.negative);
      setSelectedStyleIds(starter.styles);
      setWidth(starter.width);
      setHeight(starter.height);
      setSeedInput('');

      if (autoRun) {
        void runBatch({
          basePrompt: starter.prompt,
          negPrompt: starter.negative,
          styleIds: starter.styles,
          w: starter.width,
          h: starter.height,
          batch: batchCount,
          seedStr: '',
          stepsStr: stepsInput,
          guidanceStr: guidanceInput,
          selectedModel: model,
        });
      }
    },
    [batchCount, stepsInput, guidanceInput, model, runBatch]
  );

  const handleRetryCard = useCallback(
    async (card: GeneratedCard) => {
      setCards((prev) =>
        prev.map((item) =>
          item.id === card.id ? { ...item, status: 'pending', error: undefined } : item
        )
      );
      try {
        const res = await generate(
          {
            prompt: card.fullPrompt,
            negativePrompt: card.negativePrompt,
            width: card.width,
            height: card.height,
            seed: card.seed,
            model: card.model,
            steps: card.steps,
            guidance: card.guidance,
          },
          backendConfig
        );
        setCards((prev) =>
          prev.map((item) =>
            item.id === card.id
              ? {
                  ...item,
                  status: 'ready',
                  url: res.url,
                  seed: res.seed,
                  provider: res.provider,
                  width: res.width ?? item.width,
                  height: res.height ?? item.height,
                  durationMs: res.durationMs,
                }
              : item
          )
        );
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Generation failed.';
        setCards((prev) =>
          prev.map((item) =>
            item.id === card.id ? { ...item, status: 'error', error: errorMsg } : item
          )
        );
      }
    },
    [backendConfig]
  );

  const handleReuseCard = useCallback(
    (card: GeneratedCard) => {
      setPrompt(card.basePrompt);
      setNegativePrompt(card.negativePrompt);
      setWidth(card.width);
      setHeight(card.height);
      setSeedInput(String(card.seed));
      setStepsInput(typeof card.steps === 'number' ? String(card.steps) : '');
      setGuidanceInput(typeof card.guidance === 'number' ? String(card.guidance) : '');
      const matchedIds = STYLE_PRESETS.filter((s) => card.appliedStyles.includes(s.name)).map(
        (s) => s.id
      );
      setSelectedStyleIds(matchedIds);
      setActiveTab('studio');
      showNotice(`Loaded prompt and seed ${card.seed}`);
    },
    [showNotice]
  );

  const handleRemoveCard = useCallback(
    (id: string) => {
      setCards((prev) => {
        const target = prev.find((c) => c.id === id);
        if (target?.url?.startsWith('blob:')) {
          URL.revokeObjectURL(target.url);
        }
        return prev.filter((c) => c.id !== id);
      });
      if (lightboxId === id) setLightboxId(null);
    },
    [lightboxId]
  );

  const handleClearAll = useCallback(() => {
    setCards((prev) => {
      prev.forEach((c) => {
        if (c.url?.startsWith('blob:')) URL.revokeObjectURL(c.url);
      });
      return [];
    });
    setLightboxId(null);
  }, []);

  const handleDownloadCard = useCallback(
    async (card: GeneratedCard) => {
      if (!card.url) return;
      try {
        await downloadImageAsset(card.url, `image-forge-${card.seed}.png`);
      } catch (err) {
        showNotice(err instanceof Error ? err.message : 'Download failed.');
      }
    },
    [showNotice]
  );

  const handleExportHtml = useCallback(() => {
    const html = buildSingleFileHtml(backendConfig);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'image-forge.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1200);
    showNotice('Exported standalone image-forge.html');
  }, [backendConfig, showNotice]);

  const readyCards = useMemo(() => cards.filter((c) => c.status === 'ready' && c.url), [cards]);
  const lightboxIndex = useMemo(
    () => readyCards.findIndex((c) => c.id === lightboxId),
    [readyCards, lightboxId]
  );
  const activeLightboxCard = lightboxIndex >= 0 ? readyCards[lightboxIndex] : null;

  return (
    <div className="min-h-screen lg:h-screen flex flex-col bg-[#0C0E12] text-[#ECEEF2] overflow-x-hidden">
      <TopBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onExportHtml={handleExportHtml}
      />

      {activeTab === 'studio' ? (
        <main className="flex-1 min-h-0 flex flex-col lg:flex-row">
          <ControlsSidebar
            prompt={prompt}
            onPromptChange={setPrompt}
            negativePrompt={negativePrompt}
            onNegativePromptChange={setNegativePrompt}
            selectedStyleIds={selectedStyleIds}
            onToggleStyle={handleToggleStyle}
            width={width}
            height={height}
            onDimensionsChange={(w, h) => {
              setWidth(w);
              setHeight(h);
            }}
            batchCount={batchCount}
            onBatchCountChange={setBatchCount}
            seedInput={seedInput}
            onSeedInputChange={setSeedInput}
            backendId={backendConfig.id}
            onBackendIdChange={handleBackendIdChange}
            model={model}
            onModelChange={setModel}
            stepsInput={stepsInput}
            onStepsInputChange={setStepsInput}
            guidanceInput={guidanceInput}
            onGuidanceInputChange={setGuidanceInput}
            customEndpointUrl={backendConfig.customEndpointUrl}
            onCustomEndpointUrlChange={(url) =>
              setBackendConfig((prev) => ({ ...prev, customEndpointUrl: url }))
            }
            isGenerating={activeJobs > 0}
            progressText={progressText}
            onGenerate={handleGenerate}
          />
          <GalleryStage
            cards={cards}
            backendId={backendConfig.id}
            onSelectCard={(card) => setLightboxId(card.id)}
            onDownloadCard={handleDownloadCard}
            onReuseCard={handleReuseCard}
            onRetryCard={handleRetryCard}
            onRemoveCard={handleRemoveCard}
            onClearAll={handleClearAll}
            onApplyStarter={handleApplyStarter}
            onSwitchToLocalMock={() => {
              handleBackendIdChange('local-mock');
              showNotice('Switched backend to Local Mock (zero-key)');
            }}
          />
        </main>
      ) : (
        <main className="flex-1 min-h-0 flex flex-col">
          <BackendAdapterView
            config={backendConfig}
            onChangeConfig={handleConfigChange}
            onExportHtml={handleExportHtml}
          />
        </main>
      )}

      <LightboxModal
        card={activeLightboxCard}
        hasPrev={lightboxIndex > 0}
        hasNext={lightboxIndex >= 0 && lightboxIndex < readyCards.length - 1}
        onPrev={() => {
          if (lightboxIndex > 0) setLightboxId(readyCards[lightboxIndex - 1].id);
        }}
        onNext={() => {
          if (lightboxIndex < readyCards.length - 1) {
            setLightboxId(readyCards[lightboxIndex + 1].id);
          }
        }}
        onClose={() => setLightboxId(null)}
        onDownload={handleDownloadCard}
        onReuse={handleReuseCard}
      />

      {notice && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 px-4 py-2.5 text-xs font-medium text-[#ECEEF2] bg-[#1B1F29] border border-[#3A4254] rounded-lg shadow-lg"
        >
          {notice}
        </div>
      )}
    </div>
  );
}
