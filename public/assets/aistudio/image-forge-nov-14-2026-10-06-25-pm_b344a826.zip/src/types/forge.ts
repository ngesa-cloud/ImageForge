export type BackendId = 'auto' | 'pollinations' | 'local-mock' | 'custom-http';

export interface BackendConfig {
  id: BackendId;
  customEndpointUrl: string;
  customAuthHeader: string;
  useServerProxy: boolean;
}

export interface StylePreset {
  id: string;
  name: string;
  suffix: string;
  description: string;
}

export interface AspectPreset {
  id: string;
  label: string;
  ratio: string;
  width: number;
  height: number;
}

export interface ModelOption {
  id: string;
  label: string;
  note: string;
}

export interface GenerationParams {
  prompt: string;
  negativePrompt: string;
  width: number;
  height: number;
  seed: number;
  model: string;
  steps?: number;
  guidance?: number;
}

export interface GenerateResult {
  url: string;
  seed: number;
  width?: number;
  height?: number;
  durationMs: number;
  backend: BackendId;
  provider: string;
}

export interface CustomHealthResult {
  ok: boolean;
  model?: string;
  device?: string;
  loaded?: boolean;
  error?: string;
}

export type CardStatus = 'pending' | 'ready' | 'error';

export interface GeneratedCard {
  id: string;
  basePrompt: string;
  fullPrompt: string;
  negativePrompt: string;
  appliedStyles: string[];
  width: number;
  height: number;
  seed: number;
  model: string;
  steps?: number;
  guidance?: number;
  backend: BackendId;
  provider?: string;
  status: CardStatus;
  url?: string;
  error?: string;
  durationMs?: number;
  createdAt: number;
}
